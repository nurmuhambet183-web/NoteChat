//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cd6qjh2s.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-3libPw6u.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-3libPw6u.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CMaGDEqN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
