import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as ArrowLeft, C as CornerUpLeft, D as CheckCheck, E as Check, O as Bookmark, S as Eye, T as ChevronDown, _ as Moon, b as FileText, c as Settings, d as Play, f as Pin, g as Paperclip, h as Pause, i as UserPlus, j as Archive, k as BellOff, l as Send, m as Pencil, n as Users, o as Trash2, p as Phone, r as UserRound, s as Smile, t as X, u as Search, v as Mic, w as Copy, x as Feather, y as Menu } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-a6CCABsU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var MONTHS = [
	"января",
	"февраля",
	"марта",
	"апреля",
	"мая",
	"июня",
	"июля",
	"августа",
	"сентября",
	"октября",
	"ноября",
	"декабря"
];
function initials(name) {
	const parts = name.trim().split(/\s+/).filter(Boolean).slice(0, 2);
	if (!parts.length) return "•";
	return parts.map((part) => part[0].toUpperCase()).join("");
}
function formatClock(at) {
	return new Intl.DateTimeFormat("ru-RU", {
		hour: "2-digit",
		minute: "2-digit"
	}).format(new Date(at));
}
function formatListTime(at, now = Date.now()) {
	const date = new Date(at);
	const today = new Date(now);
	if (date.toDateString() === today.toDateString()) return formatClock(at);
	const yesterday = new Date(now);
	yesterday.setDate(yesterday.getDate() - 1);
	if (date.toDateString() === yesterday.toDateString()) return "вчера";
	if (now - at < 6048e5) return new Intl.DateTimeFormat("ru-RU", { weekday: "short" }).format(date);
	return new Intl.DateTimeFormat("ru-RU", {
		day: "2-digit",
		month: "2-digit",
		year: "2-digit"
	}).format(date);
}
function formatDayChip(at, now = Date.now()) {
	const date = new Date(at);
	const today = new Date(now);
	if (date.toDateString() === today.toDateString()) return "Сегодня";
	const yesterday = new Date(now);
	yesterday.setDate(yesterday.getDate() - 1);
	if (date.toDateString() === yesterday.toDateString()) return "Вчера";
	return `${date.getDate()} ${MONTHS[date.getMonth()]}`;
}
function formatBytes(size) {
	if (size < 1024) return `${size} Б`;
	if (size < 1048576) return `${Math.max(1, Math.round(size / 1024))} КБ`;
	return `${(size / 1024 / 1024).toFixed(1)} МБ`;
}
function formatDuration(seconds) {
	const total = Math.max(0, Math.round(seconds));
	return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}
var now = Date.now();
var ago = (minutes) => now - minutes * 6e4;
var AVATAR_COLORS = [
	"#e17076",
	"#faa774",
	"#a695e7",
	"#7bc862",
	"#6ec9cb",
	"#65aadd",
	"#ee7aae",
	"#f5c65d"
];
var SEED_PROFILE = {
	name: "Алексей Морозов",
	bio: "Делаю NoteChat",
	phone: "+7 916 555-01-27",
	color: "#3390ec"
};
var SEED_CHATS = [
	{
		id: "saved",
		title: "Избранное",
		color: "#3390ec",
		initials: "",
		kind: "saved",
		status: "заметки себе",
		folder: "personal",
		unread: 0
	},
	{
		id: "anna",
		title: "Анна Ковалева",
		color: "#ee7aae",
		initials: "АК",
		kind: "user",
		status: "в сети",
		online: true,
		folder: "personal",
		pinned: true,
		unread: 2
	},
	{
		id: "family",
		title: "Семья",
		color: "#7bc862",
		initials: "С",
		kind: "group",
		status: "Мама, Папа, Лиза",
		folder: "personal",
		pinned: true,
		unread: 3,
		pinnedMessageId: "fam-pin",
		members: [
			{
				name: "Мама",
				color: "#e17076"
			},
			{
				name: "Папа",
				color: "#65aadd"
			},
			{
				name: "Лиза",
				color: "#ee7aae"
			}
		]
	},
	{
		id: "maxim",
		title: "Максим Орлов",
		color: "#65aadd",
		initials: "МО",
		kind: "user",
		status: "был в 14:32",
		folder: "work",
		unread: 0
	},
	{
		id: "kate",
		title: "Катя",
		color: "#a695e7",
		initials: "К",
		kind: "user",
		status: "была недавно",
		online: true,
		folder: "personal",
		unread: 1
	},
	{
		id: "mama",
		title: "Мама",
		color: "#e17076",
		initials: "М",
		kind: "user",
		status: "была недавно",
		folder: "personal",
		unread: 0
	},
	{
		id: "oleg",
		title: "Олег Петров",
		color: "#faa774",
		initials: "ОП",
		kind: "user",
		status: "был вчера",
		folder: "work",
		unread: 0
	},
	{
		id: "design",
		title: "Дизайн-чат",
		color: "#6ec9cb",
		initials: "Д",
		kind: "group",
		status: "Ника, Глеб, Соня",
		folder: "work",
		muted: true,
		unread: 4,
		members: [
			{
				name: "Ника",
				color: "#6ec9cb"
			},
			{
				name: "Глеб",
				color: "#faa774"
			},
			{
				name: "Соня",
				color: "#a695e7"
			}
		]
	},
	{
		id: "team",
		title: "Команда",
		color: "#65aadd",
		initials: "К",
		kind: "group",
		status: "Ира, Паша, Денис",
		folder: "work",
		unread: 0,
		members: [
			{
				name: "Ира",
				color: "#ee7aae"
			},
			{
				name: "Паша",
				color: "#7bc862"
			},
			{
				name: "Денис",
				color: "#65aadd"
			}
		]
	},
	{
		id: "news",
		title: "NoteChat Новости",
		color: "#3390ec",
		initials: "",
		kind: "channel",
		status: "1 284 подписчика",
		folder: "personal",
		unread: 1
	}
];
var read = "read";
var SEED_MESSAGES = [
	{
		id: "sv-1",
		chatId: "saved",
		out: true,
		text: "Вайфай дома: feather-guest / notechat",
		at: ago(3e3),
		status: read
	},
	{
		id: "sv-2",
		chatId: "saved",
		out: true,
		text: "Идея: пустой экран — большое пёрышко и фраза «Выберите чат».",
		at: ago(1800),
		status: read
	},
	{
		id: "sv-3",
		chatId: "saved",
		out: true,
		text: "Купить: кофе, бумага для заметок, зарядка.",
		at: ago(400),
		status: read
	},
	{
		id: "an-1",
		chatId: "anna",
		out: true,
		text: "Макет шапки почти готов, глянешь сегодня?",
		at: ago(1560),
		status: read
	},
	{
		id: "an-2",
		chatId: "anna",
		out: false,
		text: "Кидай сюда, я как раз на ревью.",
		at: ago(1500),
		status: read
	},
	{
		id: "an-3",
		chatId: "anna",
		out: true,
		text: "Ок. Хочу ещё проверить пустой экран и список чатов.",
		at: ago(1440),
		status: read
	},
	{
		id: "an-4",
		chatId: "anna",
		out: false,
		text: "Давай до созвона. Он в 16:00, не забудь.",
		at: ago(1200),
		status: read
	},
	{
		id: "an-5",
		chatId: "anna",
		out: true,
		text: "Буду. Скину ссылку за час.",
		at: ago(180),
		status: read
	},
	{
		id: "an-6",
		chatId: "anna",
		out: false,
		text: "Привет! Ты ещё в офисе?",
		at: ago(28),
		status: read
	},
	{
		id: "an-7",
		chatId: "anna",
		out: false,
		text: "Хочу глянуть экран до созвона.",
		at: ago(26),
		status: read,
		reactions: [{
			emoji: "❤️",
			count: 1,
			mine: false
		}]
	},
	{
		id: "fam-0",
		chatId: "family",
		out: false,
		text: "Лиза закрепила сообщение",
		at: ago(320),
		status: read,
		service: true
	},
	{
		id: "fam-pin",
		chatId: "family",
		out: false,
		author: "Мама",
		authorColor: "#e17076",
		text: "Обед в воскресенье, в час у нас. Кто что берёт?",
		at: ago(300),
		status: read
	},
	{
		id: "fam-2",
		chatId: "family",
		out: false,
		author: "Папа",
		authorColor: "#65aadd",
		text: "Я за салатом.",
		at: ago(270),
		status: read
	},
	{
		id: "fam-3",
		chatId: "family",
		out: true,
		text: "Буду. Возьму хлеб по дороге.",
		at: ago(240),
		status: read
	},
	{
		id: "fam-4",
		chatId: "family",
		out: false,
		author: "Лиза",
		authorColor: "#ee7aae",
		text: "Торт уже заказала, заберу утром.",
		at: ago(30),
		status: read,
		reactions: [{
			emoji: "👍",
			count: 2,
			mine: true
		}]
	},
	{
		id: "fam-5",
		chatId: "family",
		out: false,
		author: "Мама",
		authorColor: "#e17076",
		text: "Только без опозданий, пожалуйста.",
		at: ago(20),
		status: read
	},
	{
		id: "fam-6",
		chatId: "family",
		out: false,
		author: "Папа",
		authorColor: "#65aadd",
		text: "Мы выйдем заранее.",
		at: ago(12),
		status: read
	},
	{
		id: "mx-1",
		chatId: "maxim",
		out: false,
		text: "Скинул сборку. Глянь, когда будет минута.",
		at: ago(480),
		status: read
	},
	{
		id: "mx-2",
		chatId: "maxim",
		out: false,
		text: "",
		file: {
			name: "Макет_v3.pdf",
			size: "2.4 МБ"
		},
		at: ago(479),
		status: read
	},
	{
		id: "mx-3",
		chatId: "maxim",
		out: true,
		text: "Открыл. Вечером напишу комментарии.",
		at: ago(360),
		status: read
	},
	{
		id: "kt-1",
		chatId: "kate",
		out: true,
		text: "Ты в субботу свободна?",
		at: ago(600),
		status: read
	},
	{
		id: "kt-2",
		chatId: "kate",
		out: false,
		text: "",
		voice: { seconds: 8 },
		at: ago(40),
		status: read
	},
	{
		id: "kt-3",
		chatId: "kate",
		out: false,
		text: "Давай после обеда, я как раз в центре.",
		at: ago(38),
		status: read
	},
	{
		id: "ma-1",
		chatId: "mama",
		out: false,
		text: "Алёша, ты сегодня домой?",
		at: ago(1080),
		status: read
	},
	{
		id: "ma-2",
		chatId: "mama",
		out: true,
		text: "Да, ближе к девяти. Не ждите с ужином.",
		at: ago(1020),
		status: read
	},
	{
		id: "ma-3",
		chatId: "mama",
		out: false,
		text: "Хорошо. Суп в холодильнике.",
		at: ago(960),
		status: read
	},
	{
		id: "ol-1",
		chatId: "oleg",
		out: false,
		text: "Пуш с правками шрифта уже в ветке.",
		at: ago(1680),
		status: read
	},
	{
		id: "ol-2",
		chatId: "oleg",
		out: true,
		text: "Вижу. Завтра сверю с макетом.",
		at: ago(1560),
		status: read
	},
	{
		id: "ds-1",
		chatId: "design",
		out: false,
		author: "Ника",
		authorColor: "#6ec9cb",
		text: "Убрала лишнюю тень у пузырей. Так спокойнее.",
		at: ago(90),
		status: read
	},
	{
		id: "ds-2",
		chatId: "design",
		out: false,
		author: "Глеб",
		authorColor: "#faa774",
		text: "Синий оставила тот же, #3390EC.",
		at: ago(80),
		status: read
	},
	{
		id: "ds-3",
		chatId: "design",
		out: true,
		text: "Отлично. Пёрышко в пустом чате крупное.",
		at: ago(70),
		status: read
	},
	{
		id: "ds-4",
		chatId: "design",
		out: false,
		author: "Соня",
		authorColor: "#a695e7",
		text: "На тёмной теме исходящие лучше синие, не зелёные.",
		at: ago(18),
		status: read
	},
	{
		id: "ds-5",
		chatId: "design",
		out: false,
		author: "Ника",
		authorColor: "#6ec9cb",
		text: "Согласна. Залила оба варианта в файл.",
		at: ago(16),
		status: read
	},
	{
		id: "ds-6",
		chatId: "design",
		out: false,
		author: "Глеб",
		authorColor: "#faa774",
		text: "И отступ у времени внутри пузыря поправила.",
		at: ago(14),
		status: read
	},
	{
		id: "ds-7",
		chatId: "design",
		out: false,
		author: "Соня",
		authorColor: "#a695e7",
		text: "Можно смотреть.",
		at: ago(9),
		status: read
	},
	{
		id: "tm-1",
		chatId: "team",
		out: false,
		author: "Ира",
		authorColor: "#ee7aae",
		text: "Стендап в 11, как обычно.",
		at: ago(300),
		status: read
	},
	{
		id: "tm-2",
		chatId: "team",
		out: false,
		author: "Паша",
		authorColor: "#7bc862",
		text: "Я на месте.",
		at: ago(304),
		status: read
	},
	{
		id: "tm-3",
		chatId: "team",
		out: true,
		text: "Буду. Возьму список багов.",
		at: ago(240),
		status: read
	},
	{
		id: "nw-1",
		chatId: "news",
		out: false,
		text: "NoteChat открылся. Пишите друг другу так же просто, как раньше — только вместо бумажного самолётика у нас пёрышко.",
		at: ago(2400),
		status: read,
		views: 980
	},
	{
		id: "nw-2",
		chatId: "news",
		out: false,
		text: "Ночное оформление уже внутри: меню слева → Ночной режим. Исходящие в темноте становятся синими.",
		at: ago(50),
		status: read,
		views: 214
	}
].sort((a, b) => a.at - b.at);
var POOLS = {
	anna: [
		"Да, вижу. Давай так и оставим.",
		"Красиво. Только отступ сверху чуть больше.",
		"Ок, я на связи до шести.",
		"Пришли ещё вариант с тёмной темой.",
		"Уже открыла, смотрю.",
		"Согласна, так спокойнее читается."
	],
	mama: [
		"Хорошо, сынок.",
		"Не задерживайся.",
		"Я как раз на кухне.",
		"Папа тоже будет.",
		"Возьми хлеб по дороге, пожалуйста."
	],
	maxim: [
		"Принял, гляну вечером.",
		"Можем созвониться на десять минут?",
		"Ок, без проблем.",
		"Я в дороге, отвечу чуть позже."
	],
	kate: [
		"Ахах, точно.",
		"Давай в субботу.",
		"Я за.",
		"Напомни мне утром.",
		"Тогда в три у метро."
	],
	oleg: [
		"Сделал, проверь сборку.",
		"У меня собралось.",
		"Пушну через час.",
		"Ок, беру в работу."
	],
	family: [
		"Я буду!",
		"Можно я с пирогом?",
		"Во сколько встречаемся?",
		"Не опаздывайте.",
		"Уже выезжаем."
	],
	design: [
		"Поставила в макет.",
		"Давайте без лишней тени.",
		"Цвет кнопки ок.",
		"Залила в файл."
	],
	team: [
		"Вижу в треде.",
		"Могу взять это сегодня.",
		"Созвон в силе.",
		"Ок, отметил."
	]
};
var GENERIC = [
	"Понял.",
	"Ок!",
	"Сейчас гляну.",
	"Интересно.",
	"Давай.",
	"Напиши чуть подробнее.",
	"Договорились.",
	"Хорошо."
];
function replyFor(chatId, text) {
	const value = text.toLowerCase();
	if (/привет|здравств|хай/.test(value)) return "Привет! Как ты?";
	if (/как дела|как ты/.test(value)) return "Всё хорошо, а у тебя?";
	if (/спасибо|благодар/.test(value)) return "Пожалуйста!";
	if (/пока|спокойной|доброй ночи/.test(value)) return "Пока! На связи.";
	const pool = POOLS[chatId] ?? GENERIC;
	return pool[Math.floor(Math.random() * pool.length)] ?? "Ок.";
}
var KEY = "notechat-v1";
function readSaved() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const value = JSON.parse(raw);
		if (!value || !Array.isArray(value.chats) || !Array.isArray(value.messages)) return null;
		return value;
	} catch {
		return null;
	}
}
function persistable(messages) {
	return messages.map((message) => {
		if (!message.file?.imageUrl) return message;
		const file = { ...message.file };
		delete file.imageUrl;
		return {
			...message,
			file
		};
	});
}
var subscribed = false;
var toastTimer = null;
var pending = /* @__PURE__ */ new Map();
function scheduleReply(chatId) {
	const previous = pending.get(chatId);
	if (previous) clearTimeout(previous);
	useChat.setState({ typingChatId: chatId });
	const timer = setTimeout(() => {
		pending.delete(chatId);
		const state = useChat.getState();
		const chat = state.chats.find((item) => item.id === chatId);
		if (!chat || chat.kind !== "user" && chat.kind !== "group") {
			if (state.typingChatId === chatId) useChat.setState({ typingChatId: null });
			return;
		}
		const lastOut = [...state.messages].reverse().find((message) => message.chatId === chatId && message.out);
		const member = chat.kind === "group" && chat.members?.length ? chat.members[Math.floor(Math.random() * chat.members.length)] : void 0;
		const incoming = {
			id: crypto.randomUUID(),
			chatId,
			out: false,
			text: replyFor(chat.id, lastOut?.text ?? ""),
			at: Date.now(),
			status: "read",
			author: member?.name,
			authorColor: member?.color
		};
		const viewing = state.activeId === chatId;
		useChat.setState({
			typingChatId: state.typingChatId === chatId ? null : state.typingChatId,
			messages: [...state.messages.map((message) => message.chatId === chatId && message.out ? {
				...message,
				status: "read"
			} : message), incoming],
			chats: state.chats.map((item) => item.id === chatId ? {
				...item,
				unread: viewing ? 0 : item.unread + 1
			} : item)
		});
	}, 850 + Math.random() * 1100);
	pending.set(chatId, timer);
}
var useChat = create((set, get) => ({
	ready: false,
	theme: "day",
	profile: SEED_PROFILE,
	chats: SEED_CHATS,
	messages: SEED_MESSAGES,
	activeId: null,
	typingChatId: null,
	folder: "all",
	query: "",
	page: "chats",
	menuOpen: false,
	replyToId: null,
	chatSearch: false,
	chatQuery: "",
	toast: null,
	listMenu: null,
	msgMenu: null,
	unreadAnchor: null,
	hydrate: () => {
		const saved = readSaved();
		if (saved) set({
			theme: saved.theme === "night" ? "night" : "day",
			profile: {
				...SEED_PROFILE,
				...saved.profile
			},
			chats: saved.chats,
			messages: saved.messages,
			ready: true
		});
		else set({ ready: true });
		if (!subscribed && typeof window !== "undefined") {
			subscribed = true;
			useChat.subscribe((state) => {
				if (!state.ready) return;
				const payload = {
					theme: state.theme,
					profile: state.profile,
					chats: state.chats,
					messages: persistable(state.messages)
				};
				localStorage.setItem(KEY, JSON.stringify(payload));
			});
		}
	},
	toggleTheme: () => set((state) => ({ theme: state.theme === "day" ? "night" : "day" })),
	setProfile: (patch) => set((state) => ({ profile: {
		...state.profile,
		...patch
	} })),
	setFolder: (folder) => set({ folder }),
	setQuery: (query) => set({ query }),
	setPage: (page) => set({
		page,
		menuOpen: false
	}),
	setMenuOpen: (menuOpen) => set({
		menuOpen,
		listMenu: null,
		msgMenu: null
	}),
	openChat: (id) => {
		const chat = get().chats.find((item) => item.id === id);
		set((state) => ({
			activeId: id,
			page: "chats",
			menuOpen: false,
			replyToId: null,
			chatSearch: false,
			chatQuery: "",
			listMenu: null,
			msgMenu: null,
			unreadAnchor: chat && chat.unread > 0 ? {
				chatId: id,
				count: chat.unread
			} : null,
			chats: state.chats.map((item) => item.id === id ? {
				...item,
				unread: 0
			} : item)
		}));
	},
	closeChat: () => set({
		activeId: null,
		replyToId: null,
		chatSearch: false,
		chatQuery: "",
		unreadAnchor: null
	}),
	setDraft: (id, draft) => set((state) => ({ chats: state.chats.map((chat) => chat.id === id ? {
		...chat,
		draft
	} : chat) })),
	send: (text, extras) => {
		const state = get();
		const chat = state.chats.find((item) => item.id === state.activeId);
		if (!chat || chat.kind === "channel") return;
		const body = text.trim();
		if (!body && !extras?.file && !extras?.voice) return;
		const message = {
			id: crypto.randomUUID(),
			chatId: chat.id,
			out: true,
			text: body,
			at: Date.now(),
			status: chat.kind === "saved" ? "read" : "sent",
			replyId: state.replyToId ?? void 0,
			file: extras?.file,
			voice: extras?.voice
		};
		set({
			messages: [...state.messages, message],
			replyToId: null,
			chats: state.chats.map((item) => item.id === chat.id ? {
				...item,
				draft: "",
				unread: 0
			} : item)
		});
		if (chat.kind === "user" || chat.kind === "group") scheduleReply(chat.id);
	},
	setReply: (replyToId) => set({
		replyToId,
		msgMenu: null
	}),
	deleteMessage: (id) => set((state) => ({
		messages: state.messages.filter((message) => message.id !== id),
		msgMenu: null,
		replyToId: state.replyToId === id ? null : state.replyToId
	})),
	toggleReaction: (id, emoji) => set((state) => ({
		msgMenu: null,
		messages: state.messages.map((message) => {
			if (message.id !== id) return message;
			const reactions = message.reactions ? [...message.reactions] : [];
			const index = reactions.findIndex((reaction) => reaction.emoji === emoji);
			if (index === -1) reactions.push({
				emoji,
				count: 1,
				mine: true
			});
			else if (reactions[index].mine) {
				const next = {
					...reactions[index],
					count: reactions[index].count - 1,
					mine: false
				};
				if (next.count <= 0) reactions.splice(index, 1);
				else reactions[index] = next;
			} else reactions[index] = {
				...reactions[index],
				count: reactions[index].count + 1,
				mine: true
			};
			return {
				...message,
				reactions
			};
		})
	})),
	togglePin: (id) => set((state) => ({
		listMenu: null,
		chats: state.chats.map((chat) => chat.id === id ? {
			...chat,
			pinned: !chat.pinned
		} : chat)
	})),
	toggleMute: (id) => set((state) => ({
		listMenu: null,
		chats: state.chats.map((chat) => chat.id === id ? {
			...chat,
			muted: !chat.muted
		} : chat)
	})),
	toggleArchive: (id) => set((state) => ({
		listMenu: null,
		activeId: state.activeId === id ? null : state.activeId,
		chats: state.chats.map((chat) => chat.id === id ? {
			...chat,
			archived: !chat.archived,
			pinned: false
		} : chat)
	})),
	markUnread: (id) => set((state) => ({
		listMenu: null,
		chats: state.chats.map((chat) => chat.id === id ? {
			...chat,
			unread: Math.max(1, chat.unread)
		} : chat)
	})),
	createContact: (name) => {
		const title = name.trim();
		if (!title) return;
		const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)] ?? "#65aadd";
		const chat = {
			id: crypto.randomUUID(),
			title,
			color,
			initials: initials(title),
			kind: "user",
			status: "был(а) недавно",
			folder: "personal",
			unread: 0
		};
		set((state) => ({
			chats: [chat, ...state.chats],
			activeId: chat.id,
			page: "chats",
			menuOpen: false,
			replyToId: null
		}));
	},
	createGroup: (name) => {
		const title = name.trim();
		if (!title) return;
		const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)] ?? "#7bc862";
		const id = crypto.randomUUID();
		const chat = {
			id,
			title,
			color,
			initials: initials(title),
			kind: "group",
			status: "только вы",
			folder: "personal",
			unread: 0,
			members: []
		};
		const service = {
			id: crypto.randomUUID(),
			chatId: id,
			out: false,
			text: "Группа создана",
			at: Date.now(),
			status: "read",
			service: true
		};
		set((state) => ({
			chats: [chat, ...state.chats],
			messages: [...state.messages, service],
			activeId: id,
			page: "chats",
			menuOpen: false
		}));
	},
	setChatSearch: (chatSearch) => set({
		chatSearch,
		chatQuery: chatSearch ? get().chatQuery : ""
	}),
	setChatQuery: (chatQuery) => set({ chatQuery }),
	showToast: (text) => {
		if (toastTimer) clearTimeout(toastTimer);
		set({ toast: text });
		toastTimer = setTimeout(() => useChat.setState({ toast: null }), 2200);
	},
	setListMenu: (listMenu) => set({
		listMenu,
		msgMenu: null
	}),
	setMsgMenu: (msgMenu) => set({
		msgMenu,
		listMenu: null
	}),
	closeMenus: () => set({
		listMenu: null,
		msgMenu: null
	})
}));
function LetterAvatar({ name, color, className, saved, channel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid shrink-0 place-items-center rounded-full font-medium text-tg-on-primary", className),
		style: { background: saved || channel ? void 0 : color },
		children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
			className: "size-[46%]",
			fill: "currentColor"
		}) : channel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feather, {
			className: "size-[52%]",
			strokeWidth: 1.75
		}) : initials(name)
	});
}
function Avatar({ chat, className, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("relative shrink-0", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetterAvatar, {
			name: chat.title,
			color: chat.color,
			saved: chat.kind === "saved",
			channel: chat.kind === "channel",
			className: cn("size-full text-lg", (chat.kind === "saved" || chat.kind === "channel") && "bg-tg-primary")
		}), chat.online ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute bottom-0 right-0 size-3.5 rounded-full border-2 bg-tg-online", active ? "border-tg-active" : "border-tg-bg") }) : null]
	});
}
var REACTIONS = [
	"👍",
	"❤️",
	"🔥",
	"🎉",
	"😁",
	"👎"
];
function reactionChoices() {
	return REACTIONS;
}
var EMOJI = [
	"😀",
	"😁",
	"😂",
	"😊",
	"😍",
	"😘",
	"😎",
	"🤔",
	"😢",
	"😡",
	"👍",
	"👎",
	"❤️",
	"🔥",
	"🎉",
	"✨",
	"🙏",
	"👏",
	"💯",
	"✅",
	"👀",
	"💬",
	"💙",
	"💚",
	"💛",
	"🧡",
	"💜",
	"🖤",
	"🤍",
	"⭐"
];
function messagesOf(messages, chatId) {
	return messages.filter((message) => message.chatId === chatId);
}
function sameCluster(a, b) {
	if (!a || !b || a.service || b.service) return false;
	if (a.out !== b.out || a.author !== b.author) return false;
	return Math.abs(a.at - b.at) < 3e5 && new Date(a.at).toDateString() === new Date(b.at).toDateString();
}
function Conversation() {
	const activeId = useChat((s) => s.activeId);
	const chat = useChat((s) => s.chats.find((item) => item.id === s.activeId));
	if (!chat || !activeId) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyChat, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenChat, { chat }, chat.id);
}
function EmptyChat() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "tg-wall flex h-full flex-col items-center justify-center px-6 text-center text-tg-on-primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tg-logo-shadow grid size-32 place-items-center rounded-full bg-tg-primary text-tg-on-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feather, {
					className: "size-16",
					strokeWidth: 1.6
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "tg-empty-title mt-5 text-3xl font-medium",
				children: "NoteChat"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-base text-tg-on-primary/90",
				children: "Выберите чат, чтобы начать переписку"
			})
		]
	});
}
function OpenChat({ chat }) {
	const messages = useChat((s) => s.messages);
	const typing = useChat((s) => s.typingChatId === chat.id);
	const anchor = useChat((s) => s.unreadAnchor?.chatId === chat.id ? s.unreadAnchor : null);
	const chatSearch = useChat((s) => s.chatSearch);
	const chatQuery = useChat((s) => s.chatQuery);
	const profile = useChat((s) => s.profile);
	const closeChat = useChat((s) => s.closeChat);
	const setChatSearch = useChat((s) => s.setChatSearch);
	const setChatQuery = useChat((s) => s.setChatQuery);
	const showToast = useChat((s) => s.showToast);
	const togglePin = useChat((s) => s.togglePin);
	const toggleMute = useChat((s) => s.toggleMute);
	const toggleArchive = useChat((s) => s.toggleArchive);
	const closeMenus = useChat((s) => s.closeMenus);
	const [headerMenu, setHeaderMenu] = (0, import_react.useState)(false);
	const [profileOpen, setProfileOpen] = (0, import_react.useState)(false);
	const scrollerRef = (0, import_react.useRef)(null);
	const endRef = (0, import_react.useRef)(null);
	const stickRef = (0, import_react.useRef)(true);
	const [stuck, setStuck] = (0, import_react.useState)(true);
	const thread = messagesOf(messages, chat.id).filter((message) => {
		if (!chatSearch || !chatQuery.trim()) return true;
		return `${message.text} ${message.file?.name ?? ""}`.toLowerCase().includes(chatQuery.trim().toLowerCase());
	});
	(0, import_react.useEffect)(() => {
		stickRef.current = true;
		endRef.current?.scrollIntoView();
	}, [chat.id]);
	(0, import_react.useEffect)(() => {
		if (stickRef.current) endRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [thread.length, typing]);
	const pinned = messages.find((message) => message.id === chat.pinnedMessageId);
	const status = typing ? "печатает…" : chat.online ? "в сети" : chat.status;
	const statusHot = typing || Boolean(chat.online);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-20 flex h-header shrink-0 items-center gap-2 border-b border-tg-border bg-tg-surface px-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover md:hidden",
						"aria-label": "Назад",
						onClick: closeChat,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-6" })
					}),
					chatSearch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-10 min-w-0 flex-1 items-center gap-2 rounded-full bg-tg-input px-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-tg-muted" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								autoFocus: true,
								value: chatQuery,
								onChange: (event) => setChatQuery(event.target.value),
								placeholder: "Поиск в чате",
								className: "min-w-0 flex-1 bg-transparent text-base",
								"aria-label": "Поиск в чате"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Закрыть поиск",
								onClick: () => setChatSearch(false),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5 text-tg-muted" })
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex min-w-0 flex-1 items-center gap-2.5 rounded-lg px-1 py-1 text-left hover:bg-tg-hover",
							onClick: () => setProfileOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								chat,
								className: "size-10"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-medium",
									children: chat.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("block truncate text-sm", statusHot ? "text-tg-primary" : "text-tg-muted"),
									children: status
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover",
							"aria-label": "Поиск",
							onClick: () => setChatSearch(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover",
							"aria-label": "Позвонить",
							onClick: () => showToast("Звонки появятся в следующем обновлении"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-10 place-items-center rounded-full text-tg-muted hover:text-tg-fg hover:bg-tg-hover",
							"aria-label": "Ещё",
							onClick: () => setHeaderMenu((value) => !value),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl leading-none",
								children: "⋯"
							})
						})
					] }),
					headerMenu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "fixed inset-0 z-20 cursor-default",
						"aria-label": "Закрыть",
						onClick: () => setHeaderMenu(false)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "tg-pop absolute right-2 top-14 z-30 w-56 overflow-hidden rounded-xl bg-tg-surface py-1 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderItem, {
								label: "Информация",
								onClick: () => {
									setHeaderMenu(false);
									setProfileOpen(true);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderItem, {
								label: chat.pinned ? "Открепить" : "Закрепить",
								onClick: () => {
									togglePin(chat.id);
									setHeaderMenu(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderItem, {
								label: chat.muted ? "Включить звук" : "Выключить звук",
								onClick: () => {
									toggleMute(chat.id);
									setHeaderMenu(false);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderItem, {
								label: chat.archived ? "Вернуть из архива" : "В архив",
								onClick: () => {
									toggleArchive(chat.id);
									setHeaderMenu(false);
								}
							})
						]
					})] }) : null
				]
			}),
			pinned && !chatSearch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex shrink-0 items-center gap-3 border-b border-tg-border bg-tg-surface px-4 py-2 text-left",
				onClick: () => document.getElementById(`msg-${pinned.id}`)?.scrollIntoView({
					behavior: "smooth",
					block: "center"
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-4 shrink-0 text-tg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-tg-primary",
						children: "Закреплённое сообщение"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm text-tg-muted",
						children: pinned.text
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scrollerRef,
				className: "tg-wall tg-scroll relative min-h-0 flex-1 overflow-y-auto py-3",
				onScroll: () => {
					const el = scrollerRef.current;
					if (!el) return;
					const next = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
					stickRef.current = next;
					setStuck(next);
					closeMenus();
				},
				children: [
					thread.map((message, index) => {
						const prev = thread[index - 1];
						const next = thread[index + 1];
						const showDate = !prev || new Date(prev.at).toDateString() !== new Date(message.at).toDateString();
						const showUnread = anchor && index === thread.length - anchor.count;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							id: `msg-${message.id}`,
							children: [
								showDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayChip, { at: message.at }) : null,
								showUnread ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "my-3 flex items-center gap-3 px-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tg-unread-line h-px flex-1" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-meta text-tg-on-primary",
											children: "Непрочитанные сообщения"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "tg-unread-line h-px flex-1" })
									]
								}) : null,
								message.service ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "my-2 flex justify-center px-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-tg-chip px-3 py-1 text-center text-meta text-tg-chip-fg",
										children: message.text
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubble, {
									message,
									chat,
									mine: profile.name,
									tail: !sameCluster(message, next),
									grouped: sameCluster(prev, message),
									query: chatSearch ? chatQuery : ""
								})
							]
						}, message.id);
					}),
					typing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex justify-start px-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bubble bubble-in bubble-tail",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tg-dots inline-flex items-center px-1 py-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BubbleTailSafe, {})]
						})
					}) : null,
					chatSearch && chatQuery.trim() && thread.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-tg-on-primary",
						children: "Ничего не найдено"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: endRef })
				]
			}),
			!stuck ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "tg-fab absolute bottom-24 right-4 grid size-11 place-items-center rounded-full bg-tg-surface text-tg-muted",
				"aria-label": "Вниз",
				onClick: () => endRef.current?.scrollIntoView({ behavior: "smooth" }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-5" })
			}) : null,
			chat.kind === "channel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tg-safe shrink-0 border-t border-tg-border bg-tg-surface px-4 py-4 text-center text-sm text-tg-muted",
				children: "Только администраторы публикуют в этом канале"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, { chat }),
			profileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileSheet, {
				chat,
				onClose: () => setProfileOpen(false)
			}) : null
		]
	});
}
function BubbleTailSafe() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 11 20",
		className: "absolute -left-1.5 bottom-0 h-5 w-3 -scale-x-100 text-tg-bubble-in",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M0 0c.6 3.2 2.2 6.6 5.2 10.2C7.4 13 9.2 15.2 11 17.2V20H6.2C3.4 16.4 1.2 11.2 0 0Z"
		})
	});
}
function DayChip({ at }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "my-2 flex justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded-full bg-tg-chip px-3 py-1 text-meta text-tg-chip-fg",
			children: formatDayChip(at)
		})
	});
}
function HeaderItem({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "block w-full px-4 py-2.5 text-left hover:bg-tg-hover",
		onClick,
		children: label
	});
}
function Bubble({ message, chat, mine, tail, grouped, query }) {
	const messages = useChat((s) => s.messages);
	const setMsgMenu = useChat((s) => s.setMsgMenu);
	const reply = message.replyId ? messages.find((item) => item.id === message.replyId) : void 0;
	const hold = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex px-2", message.out ? "justify-end" : "justify-start", grouped ? "mt-0.5" : "mt-2"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("relative", message.reactions?.length ? "mb-3" : ""),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("bubble", message.out ? "bubble-out" : "bubble-in", tail && "bubble-tail"),
				onContextMenu: (event) => {
					event.preventDefault();
					setMsgMenu({
						id: message.id,
						x: event.clientX,
						y: event.clientY
					});
				},
				onPointerDown: (event) => {
					if (event.pointerType === "mouse") return;
					hold.current = setTimeout(() => setMsgMenu({
						id: message.id,
						x: event.clientX,
						y: event.clientY
					}), 480);
				},
				onPointerUp: () => {
					if (hold.current) clearTimeout(hold.current);
				},
				onPointerLeave: () => {
					if (hold.current) clearTimeout(hold.current);
				},
				children: [
					!message.out && message.author && !grouped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-0.5 text-sm font-medium",
						style: { color: message.authorColor },
						children: message.author
					}) : null,
					reply ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("mb-1 border-l-2 pl-2", message.out ? "border-tg-check" : "border-tg-primary"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("text-sm font-medium", message.out ? "text-tg-meta-out" : "text-tg-primary"),
							children: reply.out ? mine : reply.author || chat.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-sm text-tg-muted",
							children: reply.text || reply.file?.name || "Голосовое сообщение"
						})]
					}) : null,
					message.file?.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: message.file.imageUrl,
						alt: "",
						className: "mb-1 max-h-64 rounded-lg"
					}) : null,
					message.file && !message.file.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex min-w-52 items-center gap-2 rounded-lg bg-tg-chip/20 px-2 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 place-items-center rounded-full bg-tg-primary text-tg-on-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm font-medium",
								children: message.file.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-meta text-tg-muted",
								children: message.file.size
							})]
						})]
					}) : null,
					message.voice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Voice, {
						seconds: message.voice.seconds,
						out: message.out,
						id: message.id
					}) : null,
					message.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "bubble-text text-msg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rich, {
							text: message.text,
							query
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "bubble-meta tabular-nums",
						children: [
							formatClock(message.at),
							typeof message.views === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }), message.views]
							}) : null,
							message.out ? message.status === "read" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, {
								className: "size-4 text-tg-check",
								strokeWidth: 2.4
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								className: "size-3.5",
								strokeWidth: 2.4
							}) : null
						]
					}),
					tail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tail, { out: message.out }) : null
				]
			}), message.reactions?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("absolute -bottom-2.5 flex gap-1", message.out ? "right-1" : "left-1"),
				children: message.reactions.map((reaction) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: cn("rounded-full bg-tg-surface px-1.5 py-0.5 text-meta shadow", reaction.mine && "ring-1 ring-tg-primary"),
					children: [reaction.emoji, reaction.count > 1 ? ` ${reaction.count}` : ""]
				}, reaction.emoji))
			}) : null]
		})
	});
}
function Tail({ out }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 11 20",
		className: cn("absolute bottom-0 h-5 w-3", out ? "-right-1.5 text-tg-bubble-out" : "-left-1.5 -scale-x-100 text-tg-bubble-in"),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M0 0c.6 3.2 2.2 6.6 5.2 10.2C7.4 13 9.2 15.2 11 17.2V20H6.2C3.4 16.4 1.2 11.2 0 0Z"
		})
	});
}
function Rich({ text, query }) {
	const pieces = text.split(/(https?:\/\/[^\s]+)/g);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: pieces.map((piece, index) => piece.startsWith("http") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: piece,
		target: "_blank",
		rel: "noreferrer",
		className: "text-tg-link underline",
		children: piece
	}, index) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Highlight, {
		text: piece,
		query
	}, index)) });
}
function Highlight({ text, query }) {
	const needle = query.trim();
	if (!needle) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: text });
	const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	const parts = text.split(new RegExp(`(${escaped})`, "ig"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: parts.map((part, index) => part.toLowerCase() === needle.toLowerCase() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mark", {
		className: "rounded-sm bg-tg-chip text-tg-chip-fg",
		children: part
	}, index) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: part }, index)) });
}
function Voice({ seconds, out, id }) {
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const bars = Array.from({ length: 26 }, (_, index) => 4 + id.charCodeAt(index % id.length) * (index + 3) % 16);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex min-w-52 items-center gap-2 py-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("grid size-10 place-items-center rounded-full text-tg-on-primary", out ? "bg-tg-check" : "bg-tg-primary"),
				"aria-label": playing ? "Пауза" : "Слушать",
				onClick: () => setPlaying((value) => !value),
				children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 translate-x-px" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex h-6 flex-1 items-center gap-0.5",
				children: bars.map((height, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("w-0.5 rounded-full", playing && index < 8 ? "bg-tg-primary" : "bg-tg-muted"),
					style: { height }
				}, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-meta tabular-nums text-tg-muted",
				children: formatDuration(seconds)
			})
		]
	});
}
function Composer({ chat }) {
	const draft = chat.draft ?? "";
	const replyToId = useChat((s) => s.replyToId);
	const messages = useChat((s) => s.messages);
	const profile = useChat((s) => s.profile);
	const setDraft = useChat((s) => s.setDraft);
	const send = useChat((s) => s.send);
	const setReply = useChat((s) => s.setReply);
	const areaRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const [emojiOpen, setEmojiOpen] = (0, import_react.useState)(false);
	const [recording, setRecording] = (0, import_react.useState)(null);
	const [tick, setTick] = (0, import_react.useState)(0);
	const reply = replyToId ? messages.find((message) => message.id === replyToId && message.chatId === chat.id) : void 0;
	(0, import_react.useEffect)(() => {
		const el = areaRef.current;
		if (!el) return;
		el.style.height = "auto";
		el.style.height = `${Math.min(el.scrollHeight, 150)}px`;
	}, [draft]);
	(0, import_react.useEffect)(() => {
		if (window.innerWidth >= 768) areaRef.current?.focus();
	}, [chat.id]);
	(0, import_react.useEffect)(() => {
		if (recording == null) return;
		const id = setInterval(() => setTick((value) => value + 1), 250);
		return () => clearInterval(id);
	}, [recording]);
	function submitText() {
		if (!draft.trim()) return;
		send(draft);
		setEmojiOpen(false);
	}
	function finishVoice() {
		if (recording == null) return;
		const seconds = Math.max(1, Math.round((Date.now() - recording) / 1e3));
		setRecording(null);
		send("", { voice: { seconds } });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative shrink-0 border-t border-tg-border bg-tg-surface",
		children: [
			reply ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 border-b border-tg-border px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerUpLeft, { className: "size-4 shrink-0 text-tg-primary" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 border-l-2 border-tg-primary pl-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-medium text-tg-primary",
							children: reply.out ? profile.name : reply.author || chat.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-sm text-tg-muted",
							children: reply.text || reply.file?.name || "Голосовое сообщение"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Отменить ответ",
						onClick: () => setReply(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5 text-tg-muted" })
					})
				]
			}) : null,
			emojiOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-8 gap-1 border-b border-tg-border bg-tg-surface p-2",
				children: EMOJI.map((emoji) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid h-10 place-items-center rounded-lg text-xl hover:bg-tg-hover",
					onClick: () => {
						const el = areaRef.current;
						const start = el?.selectionStart ?? draft.length;
						const end = el?.selectionEnd ?? draft.length;
						const next = `${draft.slice(0, start)}${emoji}${draft.slice(end)}`;
						setDraft(chat.id, next);
						requestAnimationFrame(() => {
							el?.focus();
							const pos = start + emoji.length;
							el?.setSelectionRange(pos, pos);
						});
					},
					children: emoji
				}, emoji))
			}) : null,
			recording != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tg-safe flex items-center gap-3 px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-sm text-tg-danger",
						onClick: () => setRecording(null),
						children: "Отмена"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-tg-danger" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-tg-fg",
						children: formatDuration((Date.now() - recording) / 1e3)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-tg-muted",
						children: ["запись", tick ? "" : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ml-auto grid size-10 place-items-center text-tg-primary",
						"aria-label": "Отправить голосовое",
						onClick: finishVoice,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-6" })
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tg-safe flex items-end gap-1 px-1 py-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover",
						"aria-label": "Прикрепить",
						onClick: () => fileRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						className: "hidden",
						onChange: (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							if (!file) return;
							const imageUrl = file.type.startsWith("image/") ? URL.createObjectURL(file) : void 0;
							send(imageUrl ? "" : "", { file: {
								name: file.name,
								size: formatBytes(file.size),
								imageUrl
							} });
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 items-end rounded-3xl bg-tg-input px-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							ref: areaRef,
							rows: 1,
							value: draft,
							placeholder: "Сообщение",
							"aria-label": "Сообщение",
							className: "max-h-36 min-h-10 flex-1 resize-none bg-transparent py-2.5 text-base text-tg-fg placeholder:text-tg-muted",
							onChange: (event) => setDraft(chat.id, event.target.value),
							onKeyDown: (event) => {
								if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
									event.preventDefault();
									submitText();
								}
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mb-1 grid size-9 place-items-center text-tg-muted",
							"aria-label": "Эмодзи",
							onClick: () => setEmojiOpen((value) => !value),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smile, { className: "size-5" })
						})]
					}),
					draft.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center rounded-full text-tg-primary",
						"aria-label": "Отправить",
						onClick: submitText,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-6" })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center rounded-full text-tg-muted",
						"aria-label": "Голосовое сообщение",
						onClick: () => setRecording(Date.now()),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-6" })
					})
				]
			})
		]
	});
}
function ProfileSheet({ chat, onClose }) {
	const toggleMute = useChat((s) => s.toggleMute);
	const togglePin = useChat((s) => s.togglePin);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-30 flex justify-end bg-tg-chip",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0",
			"aria-label": "Закрыть",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "relative flex h-full w-full max-w-md flex-col bg-tg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-header items-center gap-2 px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-10 place-items-center rounded-full hover:bg-tg-hover",
					"aria-label": "Закрыть",
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-medium",
					children: "Информация"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tg-scroll min-h-0 flex-1 overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center px-6 py-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								chat,
								className: "size-28"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-xl font-medium",
								children: chat.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("mt-1 text-sm", chat.online ? "text-tg-primary" : "text-tg-muted"),
								children: chat.online ? "в сети" : chat.status
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 bg-tg-hover" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-tg-hover",
						onClick: () => togglePin(chat.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-5 text-tg-primary" }), chat.pinned ? "Открепить" : "Закрепить"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-tg-hover",
						onClick: () => toggleMute(chat.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, { className: "size-5 text-tg-primary" }), chat.muted ? "Включить уведомления" : "Выключить уведомления"]
					}),
					chat.members?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 bg-tg-hover" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "px-4 py-3 text-sm text-tg-muted",
							children: [chat.members.length, " участника"]
						}),
						chat.members.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-4 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-10 place-items-center rounded-full text-sm text-tg-on-primary",
								style: { background: member.color },
								children: member.name[0]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: member.name })]
						}, member.name))
					] }) : null
				]
			})]
		})]
	});
}
function MenuDrawer() {
	const profile = useChat((s) => s.profile);
	const theme = useChat((s) => s.theme);
	const setMenuOpen = useChat((s) => s.setMenuOpen);
	const setPage = useChat((s) => s.setPage);
	const toggleTheme = useChat((s) => s.toggleTheme);
	const openChat = useChat((s) => s.openChat);
	const showToast = useChat((s) => s.showToast);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-30",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-tg-chip",
			"aria-label": "Закрыть меню",
			onClick: () => setMenuOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "tg-drawer absolute inset-y-0 left-0 flex w-menu flex-col bg-tg-menu text-tg-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex items-center gap-3 px-4 py-5 text-left hover:bg-tg-hover",
					onClick: () => setPage("settings"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetterAvatar, {
						name: profile.name,
						color: profile.color,
						className: "size-14 bg-tg-primary text-xl"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-lg font-medium",
							children: profile.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm text-tg-muted",
							children: profile.phone
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 bg-tg-hover" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
					icon: UserPlus,
					label: "Новая группа",
					onClick: () => setPage("group")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
					icon: UserRound,
					label: "Контакты",
					onClick: () => setPage("contacts")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
					icon: Phone,
					label: "Звонки",
					onClick: () => showToast("Звонки появятся в следующем обновлении")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
					icon: Bookmark,
					label: "Избранное",
					onClick: () => openChat("saved")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
					icon: Settings,
					label: "Настройки",
					onClick: () => setPage("settings")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 bg-tg-hover" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex items-center gap-4 px-4 py-3 text-left hover:bg-tg-hover",
					onClick: toggleTheme,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-6 text-tg-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1",
							children: "Ночной режим"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("flex h-6 w-11 rounded-full p-0.5", theme === "night" ? "bg-tg-primary" : "bg-tg-badge-muted"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-5 rounded-full bg-tg-on-primary transition-transform", theme === "night" && "translate-x-5") })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-auto px-4 py-4 text-meta text-tg-muted",
					children: "NoteChat Web"
				})
			]
		})]
	});
}
function MenuRow({ icon: Icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "flex w-full items-center gap-4 px-4 py-3 text-left hover:bg-tg-hover",
		onClick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6 text-tg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function SubHeader({ title }) {
	const setPage = useChat((s) => s.setPage);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex h-header shrink-0 items-center gap-1 px-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover",
			"aria-label": "Назад",
			onClick: () => setPage("chats"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-6" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-lg font-medium",
			children: title
		})]
	});
}
function SettingsPage() {
	const profile = useChat((s) => s.profile);
	const theme = useChat((s) => s.theme);
	const setProfile = useChat((s) => s.setProfile);
	const toggleTheme = useChat((s) => s.toggleTheme);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-tg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubHeader, { title: "Настройки" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "tg-scroll min-h-0 flex-1 overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center px-8 py-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetterAvatar, {
							name: profile.name || "•",
							color: profile.color,
							className: "size-24 bg-tg-primary text-3xl"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: profile.name,
							onChange: (event) => setProfile({ name: event.target.value }),
							"aria-label": "Имя",
							className: "mt-4 w-full border-b border-tg-border bg-transparent py-1 text-center text-lg text-tg-fg"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: profile.bio,
							onChange: (event) => setProfile({ bio: event.target.value }),
							"aria-label": "О себе",
							placeholder: "О себе",
							className: "mt-2 w-full bg-transparent py-1 text-center text-sm text-tg-muted placeholder:text-tg-muted"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-meta text-tg-muted",
							children: profile.phone
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 bg-tg-hover" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-4 px-4 py-3.5 text-left hover:bg-tg-hover",
					onClick: toggleTheme,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-6 text-tg-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1",
							children: "Ночной режим"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("flex h-6 w-11 rounded-full p-0.5", theme === "night" ? "bg-tg-primary" : "bg-tg-badge-muted"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-5 rounded-full bg-tg-on-primary transition-transform", theme === "night" && "translate-x-5") })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 py-4 text-sm leading-relaxed text-tg-muted",
					children: "NoteChat хранит переписку на этом устройстве. Напишите человеку из списка — он ответит прямо в чате."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-4 pb-6 text-meta text-tg-muted",
					children: ["Инициалы: ", initials(profile.name)]
				})
			]
		})]
	});
}
function ContactsPage() {
	const chats = useChat((s) => s.chats);
	const openChat = useChat((s) => s.openChat);
	const people = chats.filter((chat) => chat.kind === "user" && !chat.archived).slice().sort((a, b) => a.title.localeCompare(b.title, "ru"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-tg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubHeader, { title: "Контакты" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "tg-scroll min-h-0 flex-1 overflow-y-auto",
			children: people.map((chat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex h-row w-full items-center gap-3 px-3 text-left hover:bg-tg-hover",
				onClick: () => openChat(chat.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetterAvatar, {
					name: chat.title,
					color: chat.color,
					className: "size-12 text-base"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate font-medium",
						children: chat.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm text-tg-muted",
						children: chat.online ? "в сети" : chat.status
					})]
				})]
			}, chat.id))
		})]
	});
}
function NewChatPage() {
	const [name, setName] = (0, import_react.useState)("");
	const chats = useChat((s) => s.chats);
	const createContact = useChat((s) => s.createContact);
	const openChat = useChat((s) => s.openChat);
	const people = chats.filter((chat) => chat.kind === "user" && !chat.archived);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-tg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubHeader, { title: "Новое сообщение" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2 px-3 py-2",
				onSubmit: (event) => {
					event.preventDefault();
					createContact(name);
					setName("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					onChange: (event) => setName(event.target.value),
					placeholder: "Имя нового контакта",
					"aria-label": "Имя нового контакта",
					className: "h-11 min-w-0 flex-1 rounded-full bg-tg-input px-4 text-base text-tg-fg placeholder:text-tg-muted"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-11 rounded-full bg-tg-primary px-4 text-sm font-medium text-tg-on-primary",
					disabled: !name.trim(),
					children: "Создать"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tg-scroll min-h-0 flex-1 overflow-y-auto",
				children: people.map((chat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex h-14 w-full items-center gap-3 px-3 text-left hover:bg-tg-hover",
					onClick: () => openChat(chat.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetterAvatar, {
						name: chat.title,
						color: chat.color,
						className: "size-11 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-medium",
						children: chat.title
					})]
				}, chat.id))
			})
		]
	});
}
function NewGroupPage() {
	const [name, setName] = (0, import_react.useState)("");
	const createGroup = useChat((s) => s.createGroup);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-tg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubHeader, { title: "Новая группа" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-3 px-4 py-4",
			onSubmit: (event) => {
				event.preventDefault();
				createGroup(name);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-20 place-items-center self-center rounded-full bg-tg-input text-tg-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-8" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					onChange: (event) => setName(event.target.value),
					placeholder: "Название группы",
					"aria-label": "Название группы",
					className: "h-11 rounded-full bg-tg-input px-4 text-base text-tg-fg placeholder:text-tg-muted"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-11 rounded-full bg-tg-primary text-sm font-medium text-tg-on-primary",
					disabled: !name.trim(),
					children: "Создать группу"
				})
			]
		})]
	});
}
var FOLDERS = [
	{
		id: "all",
		label: "Все"
	},
	{
		id: "personal",
		label: "Личные"
	},
	{
		id: "work",
		label: "Работа"
	},
	{
		id: "groups",
		label: "Группы"
	}
];
function inFolder(chat, folder) {
	if (folder === "archive") return Boolean(chat.archived);
	if (chat.archived) return false;
	if (folder === "all") return true;
	if (folder === "personal") return chat.kind === "user" || chat.kind === "saved" || chat.kind === "channel";
	if (folder === "groups") return chat.kind === "group";
	return chat.folder === "work";
}
function lastMessage(messages, chatId) {
	for (let index = messages.length - 1; index >= 0; index -= 1) {
		const message = messages[index];
		if (message && message.chatId === chatId && !message.service) return message;
	}
}
function previewText(message) {
	if (!message) return "";
	if (message.voice) return "Голосовое сообщение";
	if (message.file) return message.file.name;
	return message.text;
}
function Sidebar() {
	const folder = useChat((s) => s.folder);
	const query = useChat((s) => s.query);
	const chats = useChat((s) => s.chats);
	const messages = useChat((s) => s.messages);
	const activeId = useChat((s) => s.activeId);
	const typingChatId = useChat((s) => s.typingChatId);
	const setFolder = useChat((s) => s.setFolder);
	const setQuery = useChat((s) => s.setQuery);
	const setMenuOpen = useChat((s) => s.setMenuOpen);
	const openChat = useChat((s) => s.openChat);
	const setPage = useChat((s) => s.setPage);
	const setListMenu = useChat((s) => s.setListMenu);
	const closeMenus = useChat((s) => s.closeMenus);
	const archivedCount = chats.filter((chat) => chat.archived).length;
	const needle = query.trim().toLowerCase();
	const visible = chats.filter((chat) => {
		if (needle) {
			const last = lastMessage(messages, chat.id);
			return `${chat.title} ${previewText(last)}`.toLowerCase().includes(needle);
		}
		return inFolder(chat, folder);
	}).sort((a, b) => {
		const left = lastMessage(messages, a.id)?.at ?? 0;
		const right = lastMessage(messages, b.id)?.at ?? 0;
		if (!needle && folder !== "archive" && Boolean(a.pinned) !== Boolean(b.pinned)) return a.pinned ? -1 : 1;
		return right - left;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-tg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-header shrink-0 items-center gap-2 px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover",
					"aria-label": "Меню",
					onClick: () => setMenuOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-6" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-10 min-w-0 flex-1 items-center gap-2 rounded-full bg-tg-input px-3 text-tg-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Поиск",
						className: "min-w-0 flex-1 bg-transparent text-base text-tg-fg placeholder:text-tg-muted",
						"aria-label": "Поиск"
					})]
				})]
			}),
			folder === "archive" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-12 shrink-0 items-center gap-2 border-b border-tg-border px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "px-2 text-tg-primary",
					onClick: () => setFolder("all"),
					children: "Назад"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-medium",
					children: "Архив"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-scrollbar flex shrink-0 gap-4 overflow-x-auto border-b border-tg-border px-4",
				children: FOLDERS.map((item) => {
					const active = folder === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: cn("relative py-3 text-sm font-medium", active ? "text-tg-primary" : "text-tg-muted"),
						onClick: () => setFolder(item.id),
						children: [item.label, active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-tg-primary" }) : null]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tg-scroll min-h-0 flex-1 overflow-y-auto pb-24",
				onScroll: closeMenus,
				children: [
					folder === "all" && !needle && archivedCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-row w-full items-center gap-3 px-3 text-left hover:bg-tg-hover",
						onClick: () => setFolder("archive"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-avatar place-items-center rounded-full bg-tg-input text-tg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "Архив"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto text-sm text-tg-primary",
								children: archivedCount
							})
						]
					}) : null,
					visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-6 py-10 text-center text-sm text-tg-muted",
						children: "Ничего не найдено"
					}) : null,
					visible.map((chat) => {
						const active = chat.id === activeId;
						const last = lastMessage(messages, chat.id);
						const typing = typingChatId === chat.id;
						const draft = chat.draft?.trim();
						const time = last ? formatListTime(last.at) : "";
						let body = previewText(last);
						if (last?.out && body) body = `Вы: ${body}`;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: cn("flex h-row w-full items-center gap-3 px-2.5 text-left", active ? "bg-tg-active text-tg-on-active" : "hover:bg-tg-hover"),
							onClick: () => openChat(chat.id),
							onContextMenu: (event) => {
								event.preventDefault();
								setListMenu({
									id: chat.id,
									x: event.clientX,
									y: event.clientY
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								chat,
								active,
								className: "size-avatar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-baseline gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("truncate", chat.unread ? "font-semibold" : "font-medium"),
										children: chat.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: cn("ml-auto flex shrink-0 items-center gap-1 text-meta tabular-nums", active ? "text-tg-on-active-dim" : chat.unread ? "text-tg-primary" : "text-tg-muted"),
										children: [
											chat.pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-3.5" }) : null,
											chat.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, { className: "size-3.5" }) : null,
											time
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-0.5 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("truncate text-sm", active ? "text-tg-on-active-dim" : typing || draft ? "text-tg-primary" : "text-tg-muted"),
										children: typing ? "печатает…" : draft ? `Черновик: ${draft}` : body || "Нет сообщений"
									}), chat.unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("ml-auto grid h-5 min-w-5 shrink-0 place-items-center rounded-full px-1.5 text-meta font-medium", active ? "bg-tg-on-primary text-tg-primary" : chat.muted ? "bg-tg-badge-muted text-tg-on-primary" : "bg-tg-primary text-tg-on-primary"),
										children: chat.unread > 99 ? "99+" : chat.unread
									}) : null]
								})]
							})]
						}, chat.id);
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "tg-fab absolute bottom-5 right-5 grid size-14 place-items-center rounded-full bg-tg-primary text-tg-on-primary",
				"aria-label": "Новое сообщение",
				onClick: () => setPage("new"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-6" })
			})
		]
	});
}
function Messenger() {
	const theme = useChat((s) => s.theme);
	const page = useChat((s) => s.page);
	const menuOpen = useChat((s) => s.menuOpen);
	const activeId = useChat((s) => s.activeId);
	const toast = useChat((s) => s.toast);
	const listMenu = useChat((s) => s.listMenu);
	const msgMenu = useChat((s) => s.msgMenu);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = theme;
	}, [theme]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key !== "Escape") return;
			const state = useChat.getState();
			if (state.msgMenu || state.listMenu) {
				state.closeMenus();
				return;
			}
			if (state.menuOpen) {
				state.setMenuOpen(false);
				return;
			}
			if (state.chatSearch) {
				state.setChatSearch(false);
				return;
			}
			if (state.page !== "chats") {
				state.setPage("chats");
				return;
			}
			if (state.activeId && window.innerWidth < 768) state.closeChat();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-theme": theme,
		className: "relative flex h-dvh overflow-hidden bg-tg-bg text-tg-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: cn("relative h-full min-h-0 w-full shrink-0 border-tg-border md:flex md:w-sidebar md:border-r", activeId ? "hidden md:flex" : "flex"),
				children: [
					page === "chats" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {}) : null,
					page === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, {}) : null,
					page === "contacts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactsPage, {}) : null,
					page === "new" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewChatPage, {}) : null,
					page === "group" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewGroupPage, {}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: cn("relative min-h-0 min-w-0 flex-1 flex-col", activeId ? "flex" : "hidden md:flex"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Conversation, {})
			}),
			menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuDrawer, {}) : null,
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-tg-chip px-4 py-2 text-sm text-tg-chip-fg",
				children: toast
			}) : null,
			listMenu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListMenu, {
				x: listMenu.x,
				y: listMenu.y,
				id: listMenu.id
			}) : null,
			msgMenu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageMenu, {
				x: msgMenu.x,
				y: msgMenu.y,
				id: msgMenu.id
			}) : null
		]
	});
}
function Pop({ x, y, children, onClose }) {
	const [pos, setPos] = (0, import_react.useState)({
		left: x,
		top: y
	});
	(0, import_react.useEffect)(() => {
		setPos({
			left: Math.max(8, Math.min(x, window.innerWidth - 240 - 8)),
			top: Math.max(8, Math.min(y, window.innerHeight - 280 - 8))
		});
	}, [x, y]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "fixed inset-0 z-40 cursor-default",
		"aria-label": "Закрыть",
		onClick: onClose,
		onContextMenu: (event) => {
			event.preventDefault();
			onClose();
		}
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "tg-pop fixed z-50 w-60 overflow-hidden rounded-xl bg-tg-surface py-1 text-sm",
		style: {
			left: pos.left,
			top: pos.top
		},
		children
	})] });
}
function Item({ label, onClick, danger }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: cn("block w-full px-4 py-2.5 text-left hover:bg-tg-hover", danger && "text-tg-danger"),
		onClick,
		children: label
	});
}
function ListMenu({ x, y, id }) {
	const chat = useChat((s) => s.chats.find((item) => item.id === id));
	const closeMenus = useChat((s) => s.closeMenus);
	const togglePin = useChat((s) => s.togglePin);
	const toggleMute = useChat((s) => s.toggleMute);
	const toggleArchive = useChat((s) => s.toggleArchive);
	const markUnread = useChat((s) => s.markUnread);
	if (!chat) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pop, {
		x,
		y,
		onClose: closeMenus,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
				label: chat.pinned ? "Открепить" : "Закрепить",
				onClick: () => togglePin(id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
				label: chat.muted ? "Включить звук" : "Выключить звук",
				onClick: () => toggleMute(id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
				label: chat.archived ? "Вернуть из архива" : "В архив",
				onClick: () => toggleArchive(id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
				label: "Пометить непрочитанным",
				onClick: () => markUnread(id)
			})
		]
	});
}
function MessageMenu({ x, y, id }) {
	const message = useChat((s) => s.messages.find((item) => item.id === id));
	const closeMenus = useChat((s) => s.closeMenus);
	const setReply = useChat((s) => s.setReply);
	const deleteMessage = useChat((s) => s.deleteMessage);
	const toggleReaction = useChat((s) => s.toggleReaction);
	const showToast = useChat((s) => s.showToast);
	if (!message || message.service) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Pop, {
		x,
		y,
		onClose: closeMenus,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-between px-3 py-2",
				children: reactionChoices().map((emoji) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-8 place-items-center rounded-full text-lg hover:bg-tg-hover",
					onClick: () => toggleReaction(id, emoji),
					children: emoji
				}, emoji))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full items-center gap-3 px-4 py-2.5 text-left hover:bg-tg-hover",
				onClick: () => setReply(id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CornerUpLeft, { className: "size-4 text-tg-muted" }), " Ответить"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full items-center gap-3 px-4 py-2.5 text-left hover:bg-tg-hover",
				onClick: () => {
					const text = message.text || message.file?.name || "";
					navigator.clipboard.writeText(text).then(() => showToast("Скопировано"), () => showToast("Не удалось скопировать"));
					closeMenus();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4 text-tg-muted" }), " Копировать"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full items-center gap-3 px-4 py-2.5 text-left text-tg-danger hover:bg-tg-hover",
				onClick: () => deleteMessage(id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Удалить"]
			})
		]
	});
}
function Home() {
	const ready = useChat((s) => s.ready);
	(0, import_react.useEffect)(() => {
		useChat.getState().hydrate();
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Messenger, {});
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-dvh place-items-center bg-tg-primary text-tg-on-primary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-24 place-items-center rounded-full bg-tg-on-primary/15",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feather, {
					className: "size-12",
					strokeWidth: 1.75
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-2xl font-medium",
				children: "NoteChat"
			})]
		})
	});
}
//#endregion
export { Home as component };
