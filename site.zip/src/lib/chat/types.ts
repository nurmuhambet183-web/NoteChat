export type ThemeName = "day" | "night";

export type ChatKind = "user" | "group" | "channel" | "saved";

export type FolderId = "all" | "personal" | "work" | "groups" | "archive";

export type PageId = "chats" | "settings" | "contacts" | "new" | "group";

export type Member = { name: string; color: string };

export type Chat = {
  id: string;
  title: string;
  color: string;
  initials: string;
  kind: ChatKind;
  status: string;
  online?: boolean;
  folder: "personal" | "work";
  pinned?: boolean;
  muted?: boolean;
  archived?: boolean;
  unread: number;
  draft?: string;
  members?: Member[];
  pinnedMessageId?: string;
};

export type FileInfo = {
  name: string;
  size: string;
  imageUrl?: string;
};

export type Reaction = {
  emoji: string;
  count: number;
  mine: boolean;
};

export type Msg = {
  id: string;
  chatId: string;
  out: boolean;
  text: string;
  at: number;
  status: "sent" | "read";
  author?: string;
  authorColor?: string;
  replyId?: string;
  file?: FileInfo;
  voice?: { seconds: number };
  reactions?: Reaction[];
  service?: boolean;
  views?: number;
};

export type Profile = {
  name: string;
  bio: string;
  phone: string;
  color: string;
};

export type MenuPoint = { id: string; x: number; y: number } | null;
