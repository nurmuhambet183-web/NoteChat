import { create } from "zustand";
import { initials } from "@/lib/chat/format";
import { AVATAR_COLORS, replyFor, SEED_CHATS, SEED_MESSAGES, SEED_PROFILE } from "@/lib/chat/seed";
import type { Chat, FileInfo, FolderId, MenuPoint, Msg, PageId, Profile, ThemeName } from "@/lib/chat/types";

const KEY = "notechat-v1";

type Saved = {
  theme: ThemeName;
  profile: Profile;
  chats: Chat[];
  messages: Msg[];
};

export type ChatState = {
  ready: boolean;
  theme: ThemeName;
  profile: Profile;
  chats: Chat[];
  messages: Msg[];
  activeId: string | null;
  typingChatId: string | null;
  folder: FolderId;
  query: string;
  page: PageId;
  menuOpen: boolean;
  replyToId: string | null;
  chatSearch: boolean;
  chatQuery: string;
  toast: string | null;
  listMenu: MenuPoint;
  msgMenu: MenuPoint;
  unreadAnchor: { chatId: string; count: number } | null;
  hydrate: () => void;
  toggleTheme: () => void;
  setProfile: (patch: Partial<Profile>) => void;
  setFolder: (folder: FolderId) => void;
  setQuery: (query: string) => void;
  setPage: (page: PageId) => void;
  setMenuOpen: (open: boolean) => void;
  openChat: (id: string) => void;
  closeChat: () => void;
  setDraft: (id: string, draft: string) => void;
  send: (text: string, extras?: { file?: FileInfo; voice?: { seconds: number } }) => void;
  setReply: (id: string | null) => void;
  deleteMessage: (id: string) => void;
  toggleReaction: (id: string, emoji: string) => void;
  togglePin: (id: string) => void;
  toggleMute: (id: string) => void;
  toggleArchive: (id: string) => void;
  markUnread: (id: string) => void;
  createContact: (name: string) => void;
  createGroup: (name: string) => void;
  setChatSearch: (on: boolean) => void;
  setChatQuery: (query: string) => void;
  showToast: (text: string) => void;
  setListMenu: (menu: MenuPoint) => void;
  setMsgMenu: (menu: MenuPoint) => void;
  closeMenus: () => void;
};

function readSaved(): Saved | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const value = JSON.parse(raw) as Saved;
    if (!value || !Array.isArray(value.chats) || !Array.isArray(value.messages)) return null;
    return value;
  } catch {
    return null;
  }
}

function persistable(messages: Msg[]): Msg[] {
  return messages.map((message) => {
    if (!message.file?.imageUrl) return message;
    const file = { ...message.file };
    delete file.imageUrl;
    return { ...message, file };
  });
}

let subscribed = false;
let toastTimer: ReturnType<typeof setTimeout> | null = null;
const pending = new Map<string, ReturnType<typeof setTimeout>>();

function scheduleReply(chatId: string) {
  const previous = pending.get(chatId);
  if (previous) clearTimeout(previous);
  useChat.setState({ typingChatId: chatId });
  const timer = setTimeout(() => {
    pending.delete(chatId);
    const state = useChat.getState();
    const chat = state.chats.find((item) => item.id === chatId);
    if (!chat || (chat.kind !== "user" && chat.kind !== "group")) {
      if (state.typingChatId === chatId) useChat.setState({ typingChatId: null });
      return;
    }
    const lastOut = [...state.messages].reverse().find((message) => message.chatId === chatId && message.out);
    const member =
      chat.kind === "group" && chat.members?.length
        ? chat.members[Math.floor(Math.random() * chat.members.length)]
        : undefined;
    const incoming: Msg = {
      id: crypto.randomUUID(),
      chatId,
      out: false,
      text: replyFor(chat.id, lastOut?.text ?? ""),
      at: Date.now(),
      status: "read",
      author: member?.name,
      authorColor: member?.color,
    };
    const viewing = state.activeId === chatId;
    useChat.setState({
      typingChatId: state.typingChatId === chatId ? null : state.typingChatId,
      messages: [
        ...state.messages.map((message) =>
          message.chatId === chatId && message.out ? { ...message, status: "read" as const } : message,
        ),
        incoming,
      ],
      chats: state.chats.map((item) =>
        item.id === chatId ? { ...item, unread: viewing ? 0 : item.unread + 1 } : item,
      ),
    });
  }, 850 + Math.random() * 1100);
  pending.set(chatId, timer);
}

export const useChat = create<ChatState>((set, get) => ({
  ready: false,
  theme: "day",
  profile: SEED_PROFILE,
  chats: SEED_CHATS,
  messages: SEED_MESSAGES,
  activeId: null,
  typingChatId: null,
  folder: "all",
  query: "",
  page: "chats",
  menuOpen: false,
  replyToId: null,
  chatSearch: false,
  chatQuery: "",
  toast: null,
  listMenu: null,
  msgMenu: null,
  unreadAnchor: null,

  hydrate: () => {
    const saved = readSaved();
    if (saved) {
      set({
        theme: saved.theme === "night" ? "night" : "day",
        profile: { ...SEED_PROFILE, ...saved.profile },
        chats: saved.chats,
        messages: saved.messages,
        ready: true,
      });
    } else {
      set({ ready: true });
    }
    if (!subscribed && typeof window !== "undefined") {
      subscribed = true;
      useChat.subscribe((state) => {
        if (!state.ready) return;
        const payload: Saved = {
          theme: state.theme,
          profile: state.profile,
          chats: state.chats,
          messages: persistable(state.messages),
        };
        localStorage.setItem(KEY, JSON.stringify(payload));
      });
    }
  },

  toggleTheme: () => set((state) => ({ theme: state.theme === "day" ? "night" : "day" })),

  setProfile: (patch) => set((state) => ({ profile: { ...state.profile, ...patch } })),

  setFolder: (folder) => set({ folder }),
  setQuery: (query) => set({ query }),
  setPage: (page) => set({ page, menuOpen: false }),
  setMenuOpen: (menuOpen) => set({ menuOpen, listMenu: null, msgMenu: null }),

  openChat: (id) => {
    const chat = get().chats.find((item) => item.id === id);
    set((state) => ({
      activeId: id,
      page: "chats",
      menuOpen: false,
      replyToId: null,
      chatSearch: false,
      chatQuery: "",
      listMenu: null,
      msgMenu: null,
      unreadAnchor: chat && chat.unread > 0 ? { chatId: id, count: chat.unread } : null,
      chats: state.chats.map((item) => (item.id === id ? { ...item, unread: 0 } : item)),
    }));
  },

  closeChat: () => set({ activeId: null, replyToId: null, chatSearch: false, chatQuery: "", unreadAnchor: null }),

  setDraft: (id, draft) =>
    set((state) => ({
      chats: state.chats.map((chat) => (chat.id === id ? { ...chat, draft } : chat)),
    })),

  send: (text, extras) => {
    const state = get();
    const chat = state.chats.find((item) => item.id === state.activeId);
    if (!chat || chat.kind === "channel") return;
    const body = text.trim();
    if (!body && !extras?.file && !extras?.voice) return;
    const message: Msg = {
      id: crypto.randomUUID(),
      chatId: chat.id,
      out: true,
      text: body,
      at: Date.now(),
      status: chat.kind === "saved" ? "read" : "sent",
      replyId: state.replyToId ?? undefined,
      file: extras?.file,
      voice: extras?.voice,
    };
    set({
      messages: [...state.messages, message],
      replyToId: null,
      chats: state.chats.map((item) => (item.id === chat.id ? { ...item, draft: "", unread: 0 } : item)),
    });
    if (chat.kind === "user" || chat.kind === "group") scheduleReply(chat.id);
  },

  setReply: (replyToId) => set({ replyToId, msgMenu: null }),

  deleteMessage: (id) =>
    set((state) => ({
      messages: state.messages.filter((message) => message.id !== id),
      msgMenu: null,
      replyToId: state.replyToId === id ? null : state.replyToId,
    })),

  toggleReaction: (id, emoji) =>
    set((state) => ({
      msgMenu: null,
      messages: state.messages.map((message) => {
        if (message.id !== id) return message;
        const reactions = message.reactions ? [...message.reactions] : [];
        const index = reactions.findIndex((reaction) => reaction.emoji === emoji);
        if (index === -1) {
          reactions.push({ emoji, count: 1, mine: true });
        } else if (reactions[index]!.mine) {
          const next = { ...reactions[index]!, count: reactions[index]!.count - 1, mine: false };
          if (next.count <= 0) reactions.splice(index, 1);
          else reactions[index] = next;
        } else {
          reactions[index] = { ...reactions[index]!, count: reactions[index]!.count + 1, mine: true };
        }
        return { ...message, reactions };
      }),
    })),

  togglePin: (id) =>
    set((state) => ({
      listMenu: null,
      chats: state.chats.map((chat) => (chat.id === id ? { ...chat, pinned: !chat.pinned } : chat)),
    })),

  toggleMute: (id) =>
    set((state) => ({
      listMenu: null,
      chats: state.chats.map((chat) => (chat.id === id ? { ...chat, muted: !chat.muted } : chat)),
    })),

  toggleArchive: (id) =>
    set((state) => ({
      listMenu: null,
      activeId: state.activeId === id ? null : state.activeId,
      chats: state.chats.map((chat) =>
        chat.id === id ? { ...chat, archived: !chat.archived, pinned: false } : chat,
      ),
    })),

  markUnread: (id) =>
    set((state) => ({
      listMenu: null,
      chats: state.chats.map((chat) => (chat.id === id ? { ...chat, unread: Math.max(1, chat.unread) } : chat)),
    })),

  createContact: (name) => {
    const title = name.trim();
    if (!title) return;
    const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)] ?? "#65aadd";
    const chat: Chat = {
      id: crypto.randomUUID(),
      title,
      color,
      initials: initials(title),
      kind: "user",
      status: "был(а) недавно",
      folder: "personal",
      unread: 0,
    };
    set((state) => ({
      chats: [chat, ...state.chats],
      activeId: chat.id,
      page: "chats",
      menuOpen: false,
      replyToId: null,
    }));
  },

  createGroup: (name) => {
    const title = name.trim();
    if (!title) return;
    const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)] ?? "#7bc862";
    const id = crypto.randomUUID();
    const chat: Chat = {
      id,
      title,
      color,
      initials: initials(title),
      kind: "group",
      status: "только вы",
      folder: "personal",
      unread: 0,
      members: [],
    };
    const service: Msg = {
      id: crypto.randomUUID(),
      chatId: id,
      out: false,
      text: "Группа создана",
      at: Date.now(),
      status: "read",
      service: true,
    };
    set((state) => ({
      chats: [chat, ...state.chats],
      messages: [...state.messages, service],
      activeId: id,
      page: "chats",
      menuOpen: false,
    }));
  },

  setChatSearch: (chatSearch) => set({ chatSearch, chatQuery: chatSearch ? get().chatQuery : "" }),
  setChatQuery: (chatQuery) => set({ chatQuery }),

  showToast: (text) => {
    if (toastTimer) clearTimeout(toastTimer);
    set({ toast: text });
    toastTimer = setTimeout(() => useChat.setState({ toast: null }), 2200);
  },

  setListMenu: (listMenu) => set({ listMenu, msgMenu: null }),
  setMsgMenu: (msgMenu) => set({ msgMenu, listMenu: null }),
  closeMenus: () => set({ listMenu: null, msgMenu: null }),
}));
