import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { Feather } from "lucide-react";
import { Messenger } from "@/components/notechat/messenger";
import { useChat } from "@/lib/chat/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const ready = useChat((s) => s.ready);
  useEffect(() => {
    useChat.getState().hydrate();
  }, []);
  if (!ready) return <Splash />;
  return <Messenger />;
}

function Splash() {
  return (
    <div className="grid h-dvh place-items-center bg-tg-primary text-tg-on-primary">
      <div className="flex flex-col items-center">
        <span className="grid size-24 place-items-center rounded-full bg-tg-on-primary/15">
          <Feather className="size-12" strokeWidth={1.75} />
        </span>
        <p className="mt-4 text-2xl font-medium">NoteChat</p>
      </div>
    </div>
  );
}
