import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  BellOff,
  Check,
  CheckCheck,
  ChevronDown,
  CornerUpLeft,
  Eye,
  Feather,
  FileText,
  Mic,
  Paperclip,
  Pause,
  Phone,
  Pin,
  Play,
  Search,
  Send,
  Smile,
  X,
} from "lucide-react";
import type { Chat, Msg } from "@/lib/chat/types";
import { cn, formatBytes, formatClock, formatDayChip, formatDuration } from "@/lib/chat/format";
import { useChat } from "@/lib/chat/store";
import { Avatar } from "@/components/notechat/bits";

const EMOJI = ["😀", "😁", "😂", "😊", "😍", "😘", "😎", "🤔", "😢", "😡", "👍", "👎", "❤️", "🔥", "🎉", "✨", "🙏", "👏", "💯", "✅", "👀", "💬", "💙", "💚", "💛", "🧡", "💜", "🖤", "🤍", "⭐"];

function messagesOf(messages: Msg[], chatId: string) {
  return messages.filter((message) => message.chatId === chatId);
}

function sameCluster(a: Msg | undefined, b: Msg | undefined) {
  if (!a || !b || a.service || b.service) return false;
  if (a.out !== b.out || a.author !== b.author) return false;
  return Math.abs(a.at - b.at) < 5 * 60_000 && new Date(a.at).toDateString() === new Date(b.at).toDateString();
}

export function Conversation() {
  const activeId = useChat((s) => s.activeId);
  const chat = useChat((s) => s.chats.find((item) => item.id === s.activeId));
  if (!chat || !activeId) return <EmptyChat />;
  return <OpenChat key={chat.id} chat={chat} />;
}

function EmptyChat() {
  return (
    <div className="tg-wall flex h-full flex-col items-center justify-center px-6 text-center text-tg-on-primary">
      <span className="tg-logo-shadow grid size-32 place-items-center rounded-full bg-tg-primary text-tg-on-primary">
        <Feather className="size-16" strokeWidth={1.6} />
      </span>
      <h1 className="tg-empty-title mt-5 text-3xl font-medium">NoteChat</h1>
      <p className="mt-2 max-w-sm text-base text-tg-on-primary/90">Выберите чат, чтобы начать переписку</p>
    </div>
  );
}

function OpenChat({ chat }: { chat: Chat }) {
  const messages = useChat((s) => s.messages);
  const typing = useChat((s) => s.typingChatId === chat.id);
  const anchor = useChat((s) => (s.unreadAnchor?.chatId === chat.id ? s.unreadAnchor : null));
  const chatSearch = useChat((s) => s.chatSearch);
  const chatQuery = useChat((s) => s.chatQuery);
  const profile = useChat((s) => s.profile);
  const closeChat = useChat((s) => s.closeChat);
  const setChatSearch = useChat((s) => s.setChatSearch);
  const setChatQuery = useChat((s) => s.setChatQuery);
  const showToast = useChat((s) => s.showToast);
  const togglePin = useChat((s) => s.togglePin);
  const toggleMute = useChat((s) => s.toggleMute);
  const toggleArchive = useChat((s) => s.toggleArchive);
  const closeMenus = useChat((s) => s.closeMenus);

  const [headerMenu, setHeaderMenu] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const [stuck, setStuck] = useState(true);

  const thread = messagesOf(messages, chat.id).filter((message) => {
    if (!chatSearch || !chatQuery.trim()) return true;
    return `${message.text} ${message.file?.name ?? ""}`.toLowerCase().includes(chatQuery.trim().toLowerCase());
  });

  useEffect(() => {
    stickRef.current = true;
    endRef.current?.scrollIntoView();
  }, [chat.id]);

  useEffect(() => {
    if (stickRef.current) endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [thread.length, typing]);

  const pinned = messages.find((message) => message.id === chat.pinnedMessageId);
  const status = typing ? "печатает…" : chat.online ? "в сети" : chat.status;
  const statusHot = typing || Boolean(chat.online);

  return (
    <div className="relative flex h-full min-h-0 flex-col">
      <header className="relative z-20 flex h-header shrink-0 items-center gap-2 border-b border-tg-border bg-tg-surface px-1">
        <button type="button" className="grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover md:hidden" aria-label="Назад" onClick={closeChat}>
          <ArrowLeft className="size-6" />
        </button>
        {chatSearch ? (
          <label className="flex h-10 min-w-0 flex-1 items-center gap-2 rounded-full bg-tg-input px-3">
            <Search className="size-4 text-tg-muted" />
            <input
              autoFocus
              value={chatQuery}
              onChange={(event) => setChatQuery(event.target.value)}
              placeholder="Поиск в чате"
              className="min-w-0 flex-1 bg-transparent text-base"
              aria-label="Поиск в чате"
            />
            <button type="button" aria-label="Закрыть поиск" onClick={() => setChatSearch(false)}>
              <X className="size-5 text-tg-muted" />
            </button>
          </label>
        ) : (
          <>
            <button type="button" className="flex min-w-0 flex-1 items-center gap-2.5 rounded-lg px-1 py-1 text-left hover:bg-tg-hover" onClick={() => setProfileOpen(true)}>
              <Avatar chat={chat} className="size-10" />
              <span className="min-w-0">
                <span className="block truncate font-medium">{chat.title}</span>
                <span className={cn("block truncate text-sm", statusHot ? "text-tg-primary" : "text-tg-muted")}>{status}</span>
              </span>
            </button>
            <button type="button" className="grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover" aria-label="Поиск" onClick={() => setChatSearch(true)}>
              <Search className="size-5" />
            </button>
            <button type="button" className="grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover" aria-label="Позвонить" onClick={() => showToast("Звонки появятся в следующем обновлении")}>
              <Phone className="size-5" />
            </button>
            <button type="button" className="grid size-10 place-items-center rounded-full text-tg-muted hover:text-tg-fg hover:bg-tg-hover" aria-label="Ещё" onClick={() => setHeaderMenu((value) => !value)}>
              <span className="text-xl leading-none">⋯</span>
            </button>
          </>
        )}
        {headerMenu ? (
          <>
            <button type="button" className="fixed inset-0 z-20 cursor-default" aria-label="Закрыть" onClick={() => setHeaderMenu(false)} />
            <div className="tg-pop absolute right-2 top-14 z-30 w-56 overflow-hidden rounded-xl bg-tg-surface py-1 text-sm">
              <HeaderItem label="Информация" onClick={() => { setHeaderMenu(false); setProfileOpen(true); }} />
              <HeaderItem label={chat.pinned ? "Открепить" : "Закрепить"} onClick={() => { togglePin(chat.id); setHeaderMenu(false); }} />
              <HeaderItem label={chat.muted ? "Включить звук" : "Выключить звук"} onClick={() => { toggleMute(chat.id); setHeaderMenu(false); }} />
              <HeaderItem label={chat.archived ? "Вернуть из архива" : "В архив"} onClick={() => { toggleArchive(chat.id); setHeaderMenu(false); }} />
            </div>
          </>
        ) : null}
      </header>

      {pinned && !chatSearch ? (
        <button
          type="button"
          className="flex shrink-0 items-center gap-3 border-b border-tg-border bg-tg-surface px-4 py-2 text-left"
          onClick={() => document.getElementById(`msg-${pinned.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" })}
        >
          <Pin className="size-4 shrink-0 text-tg-primary" />
          <span className="min-w-0">
            <span className="block text-sm font-medium text-tg-primary">Закреплённое сообщение</span>
            <span className="block truncate text-sm text-tg-muted">{pinned.text}</span>
          </span>
        </button>
      ) : null}

      <div
        ref={scrollerRef}
        className="tg-wall tg-scroll relative min-h-0 flex-1 overflow-y-auto py-3"
        onScroll={() => {
          const el = scrollerRef.current;
          if (!el) return;
          const next = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
          stickRef.current = next;
          setStuck(next);
          closeMenus();
        }}
      >
        {thread.map((message, index) => {
          const prev = thread[index - 1];
          const next = thread[index + 1];
          const showDate = !prev || new Date(prev.at).toDateString() !== new Date(message.at).toDateString();
          const showUnread = anchor && index === thread.length - anchor.count;
          return (
            <div key={message.id} id={`msg-${message.id}`}>
              {showDate ? <DayChip at={message.at} /> : null}
              {showUnread ? (
                <div className="my-3 flex items-center gap-3 px-4">
                  <span className="tg-unread-line h-px flex-1" />
                  <span className="text-meta text-tg-on-primary">Непрочитанные сообщения</span>
                  <span className="tg-unread-line h-px flex-1" />
                </div>
              ) : null}
              {message.service ? (
                <div className="my-2 flex justify-center px-6">
                  <span className="rounded-full bg-tg-chip px-3 py-1 text-center text-meta text-tg-chip-fg">{message.text}</span>
                </div>
              ) : (
                <Bubble
                  message={message}
                  chat={chat}
                  mine={profile.name}
                  tail={!sameCluster(message, next)}
                  grouped={sameCluster(prev, message)}
                  query={chatSearch ? chatQuery : ""}
                />
              )}
            </div>
          );
        })}
        {typing ? (
          <div className="mt-2 flex justify-start px-2">
            <div className="bubble bubble-in bubble-tail">
              <span className="tg-dots inline-flex items-center px-1 py-1">
                <i /><i /><i />
              </span>
              <BubbleTailSafe />
            </div>
          </div>
        ) : null}
        {chatSearch && chatQuery.trim() && thread.length === 0 ? (
          <p className="py-10 text-center text-sm text-tg-on-primary">Ничего не найдено</p>
        ) : null}
        <div ref={endRef} />
      </div>

      {!stuck ? (
        <button
          type="button"
          className="tg-fab absolute bottom-24 right-4 grid size-11 place-items-center rounded-full bg-tg-surface text-tg-muted"
          aria-label="Вниз"
          onClick={() => endRef.current?.scrollIntoView({ behavior: "smooth" })}
        >
          <ChevronDown className="size-5" />
        </button>
      ) : null}

      {chat.kind === "channel" ? (
        <div className="tg-safe shrink-0 border-t border-tg-border bg-tg-surface px-4 py-4 text-center text-sm text-tg-muted">
          Только администраторы публикуют в этом канале
        </div>
      ) : (
        <Composer chat={chat} />
      )}

      {profileOpen ? <ProfileSheet chat={chat} onClose={() => setProfileOpen(false)} /> : null}
    </div>
  );
}

function BubbleTailSafe() {
  return (
    <svg viewBox="0 0 11 20" className="absolute -left-1.5 bottom-0 h-5 w-3 -scale-x-100 text-tg-bubble-in" aria-hidden="true">
      <path fill="currentColor" d="M0 0c.6 3.2 2.2 6.6 5.2 10.2C7.4 13 9.2 15.2 11 17.2V20H6.2C3.4 16.4 1.2 11.2 0 0Z" />
    </svg>
  );
}

function DayChip({ at }: { at: number }) {
  return (
    <div className="my-2 flex justify-center">
      <span className="rounded-full bg-tg-chip px-3 py-1 text-meta text-tg-chip-fg">{formatDayChip(at)}</span>
    </div>
  );
}

function HeaderItem({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button type="button" className="block w-full px-4 py-2.5 text-left hover:bg-tg-hover" onClick={onClick}>
      {label}
    </button>
  );
}

function Bubble({
  message,
  chat,
  mine,
  tail,
  grouped,
  query,
}: {
  message: Msg;
  chat: Chat;
  mine: string;
  tail: boolean;
  grouped: boolean;
  query: string;
}) {
  const messages = useChat((s) => s.messages);
  const setMsgMenu = useChat((s) => s.setMsgMenu);
  const reply = message.replyId ? messages.find((item) => item.id === message.replyId) : undefined;
  const hold = useRef<ReturnType<typeof setTimeout> | null>(null);

  return (
    <div className={cn("flex px-2", message.out ? "justify-end" : "justify-start", grouped ? "mt-0.5" : "mt-2")}>
      <div className={cn("relative", message.reactions?.length ? "mb-3" : "")}>
        <div
          className={cn("bubble", message.out ? "bubble-out" : "bubble-in", tail && "bubble-tail")}
          onContextMenu={(event) => {
            event.preventDefault();
            setMsgMenu({ id: message.id, x: event.clientX, y: event.clientY });
          }}
          onPointerDown={(event) => {
            if (event.pointerType === "mouse") return;
            hold.current = setTimeout(() => setMsgMenu({ id: message.id, x: event.clientX, y: event.clientY }), 480);
          }}
          onPointerUp={() => {
            if (hold.current) clearTimeout(hold.current);
          }}
          onPointerLeave={() => {
            if (hold.current) clearTimeout(hold.current);
          }}
        >
          {!message.out && message.author && !grouped ? (
            <div className="mb-0.5 text-sm font-medium" style={{ color: message.authorColor }}>
              {message.author}
            </div>
          ) : null}
          {reply ? (
            <div className={cn("mb-1 border-l-2 pl-2", message.out ? "border-tg-check" : "border-tg-primary")}>
              <div className={cn("text-sm font-medium", message.out ? "text-tg-meta-out" : "text-tg-primary")}>
                {reply.out ? mine : reply.author || chat.title}
              </div>
              <div className="truncate text-sm text-tg-muted">{reply.text || reply.file?.name || "Голосовое сообщение"}</div>
            </div>
          ) : null}
          {message.file?.imageUrl ? (
            <img src={message.file.imageUrl} alt="" className="mb-1 max-h-64 rounded-lg" />
          ) : null}
          {message.file && !message.file.imageUrl ? (
            <div className="mb-1 flex min-w-52 items-center gap-2 rounded-lg bg-tg-chip/20 px-2 py-1.5">
              <span className="grid size-10 place-items-center rounded-full bg-tg-primary text-tg-on-primary">
                <FileText className="size-5" />
              </span>
              <span className="min-w-0">
                <span className="block truncate text-sm font-medium">{message.file.name}</span>
                <span className="text-meta text-tg-muted">{message.file.size}</span>
              </span>
            </div>
          ) : null}
          {message.voice ? <Voice seconds={message.voice.seconds} out={message.out} id={message.id} /> : null}
          {message.text ? (
            <span className="bubble-text text-msg">
              <Rich text={message.text} query={query} />
            </span>
          ) : null}
          <span className="bubble-meta tabular-nums">
            {formatClock(message.at)}
            {typeof message.views === "number" ? (
              <span className="inline-flex items-center gap-0.5">
                <Eye className="size-3.5" />
                {message.views}
              </span>
            ) : null}
            {message.out ? message.status === "read" ? <CheckCheck className="size-4 text-tg-check" strokeWidth={2.4} /> : <Check className="size-3.5" strokeWidth={2.4} /> : null}
          </span>
          {tail ? <Tail out={message.out} /> : null}
        </div>
        {message.reactions?.length ? (
          <div className={cn("absolute -bottom-2.5 flex gap-1", message.out ? "right-1" : "left-1")}>
            {message.reactions.map((reaction) => (
              <span
                key={reaction.emoji}
                className={cn(
                  "rounded-full bg-tg-surface px-1.5 py-0.5 text-meta shadow",
                  reaction.mine && "ring-1 ring-tg-primary",
                )}
              >
                {reaction.emoji}
                {reaction.count > 1 ? ` ${reaction.count}` : ""}
              </span>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}

function Tail({ out }: { out: boolean }) {
  return (
    <svg
      viewBox="0 0 11 20"
      className={cn("absolute bottom-0 h-5 w-3", out ? "-right-1.5 text-tg-bubble-out" : "-left-1.5 -scale-x-100 text-tg-bubble-in")}
      aria-hidden="true"
    >
      <path fill="currentColor" d="M0 0c.6 3.2 2.2 6.6 5.2 10.2C7.4 13 9.2 15.2 11 17.2V20H6.2C3.4 16.4 1.2 11.2 0 0Z" />
    </svg>
  );
}

function Rich({ text, query }: { text: string; query: string }) {
  const pieces = text.split(/(https?:\/\/[^\s]+)/g);
  return (
    <>
      {pieces.map((piece, index) =>
        piece.startsWith("http") ? (
          <a key={index} href={piece} target="_blank" rel="noreferrer" className="text-tg-link underline">
            {piece}
          </a>
        ) : (
          <Highlight key={index} text={piece} query={query} />
        ),
      )}
    </>
  );
}

function Highlight({ text, query }: { text: string; query: string }) {
  const needle = query.trim();
  if (!needle) return <>{text}</>;
  const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const parts = text.split(new RegExp(`(${escaped})`, "ig"));
  return (
    <>
      {parts.map((part, index) =>
        part.toLowerCase() === needle.toLowerCase() ? (
          <mark key={index} className="rounded-sm bg-tg-chip text-tg-chip-fg">
            {part}
          </mark>
        ) : (
          <span key={index}>{part}</span>
        ),
      )}
    </>
  );
}

function Voice({ seconds, out, id }: { seconds: number; out: boolean; id: string }) {
  const [playing, setPlaying] = useState(false);
  const bars = Array.from({ length: 26 }, (_, index) => 4 + ((id.charCodeAt(index % id.length) * (index + 3)) % 16));
  return (
    <div className="mb-1 flex min-w-52 items-center gap-2 py-1">
      <button
        type="button"
        className={cn("grid size-10 place-items-center rounded-full text-tg-on-primary", out ? "bg-tg-check" : "bg-tg-primary")}
        aria-label={playing ? "Пауза" : "Слушать"}
        onClick={() => setPlaying((value) => !value)}
      >
        {playing ? <Pause className="size-4" /> : <Play className="size-4 translate-x-px" />}
      </button>
      <span className="flex h-6 flex-1 items-center gap-0.5">
        {bars.map((height, index) => (
          <span
            key={index}
            className={cn("w-0.5 rounded-full", playing && index < 8 ? "bg-tg-primary" : "bg-tg-muted")}
            style={{ height }}
          />
        ))}
      </span>
      <span className="text-meta tabular-nums text-tg-muted">{formatDuration(seconds)}</span>
    </div>
  );
}

function Composer({ chat }: { chat: Chat }) {
  const draft = chat.draft ?? "";
  const replyToId = useChat((s) => s.replyToId);
  const messages = useChat((s) => s.messages);
  const profile = useChat((s) => s.profile);
  const setDraft = useChat((s) => s.setDraft);
  const send = useChat((s) => s.send);
  const setReply = useChat((s) => s.setReply);
  const areaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [recording, setRecording] = useState<number | null>(null);
  const [tick, setTick] = useState(0);

  const reply = replyToId ? messages.find((message) => message.id === replyToId && message.chatId === chat.id) : undefined;

  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 150)}px`;
  }, [draft]);

  useEffect(() => {
    if (window.innerWidth >= 768) areaRef.current?.focus();
  }, [chat.id]);

  useEffect(() => {
    if (recording == null) return;
    const id = setInterval(() => setTick((value) => value + 1), 250);
    return () => clearInterval(id);
  }, [recording]);

  function submitText() {
    if (!draft.trim()) return;
    send(draft);
    setEmojiOpen(false);
  }

  function finishVoice() {
    if (recording == null) return;
    const seconds = Math.max(1, Math.round((Date.now() - recording) / 1000));
    setRecording(null);
    send("", { voice: { seconds } });
  }

  return (
    <div className="relative shrink-0 border-t border-tg-border bg-tg-surface">
      {reply ? (
        <div className="flex items-center gap-2 border-b border-tg-border px-3 py-2">
          <CornerUpLeft className="size-4 shrink-0 text-tg-primary" />
          <div className="min-w-0 flex-1 border-l-2 border-tg-primary pl-2">
            <div className="text-sm font-medium text-tg-primary">{reply.out ? profile.name : reply.author || chat.title}</div>
            <div className="truncate text-sm text-tg-muted">{reply.text || reply.file?.name || "Голосовое сообщение"}</div>
          </div>
          <button type="button" aria-label="Отменить ответ" onClick={() => setReply(null)}>
            <X className="size-5 text-tg-muted" />
          </button>
        </div>
      ) : null}
      {emojiOpen ? (
        <div className="grid grid-cols-8 gap-1 border-b border-tg-border bg-tg-surface p-2">
          {EMOJI.map((emoji) => (
            <button
              key={emoji}
              type="button"
              className="grid h-10 place-items-center rounded-lg text-xl hover:bg-tg-hover"
              onClick={() => {
                const el = areaRef.current;
                const start = el?.selectionStart ?? draft.length;
                const end = el?.selectionEnd ?? draft.length;
                const next = `${draft.slice(0, start)}${emoji}${draft.slice(end)}`;
                setDraft(chat.id, next);
                requestAnimationFrame(() => {
                  el?.focus();
                  const pos = start + emoji.length;
                  el?.setSelectionRange(pos, pos);
                });
              }}
            >
              {emoji}
            </button>
          ))}
        </div>
      ) : null}
      {recording != null ? (
        <div className="tg-safe flex items-center gap-3 px-3 py-2">
          <button type="button" className="text-sm text-tg-danger" onClick={() => setRecording(null)}>
            Отмена
          </button>
          <span className="size-2.5 rounded-full bg-tg-danger" />
          <span className="tabular-nums text-tg-fg">{formatDuration((Date.now() - recording) / 1000)}</span>
          <span className="text-sm text-tg-muted">запись{tick ? "" : ""}</span>
          <button type="button" className="ml-auto grid size-10 place-items-center text-tg-primary" aria-label="Отправить голосовое" onClick={finishVoice}>
            <Send className="size-6" />
          </button>
        </div>
      ) : (
        <div className="tg-safe flex items-end gap-1 px-1 py-1.5">
          <button type="button" className="grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover" aria-label="Прикрепить" onClick={() => fileRef.current?.click()}>
            <Paperclip className="size-5" />
          </button>
          <input
            ref={fileRef}
            type="file"
            className="hidden"
            onChange={(event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (!file) return;
              const imageUrl = file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined;
              send(imageUrl ? "" : "", { file: { name: file.name, size: formatBytes(file.size), imageUrl } });
            }}
          />
          <div className="flex min-w-0 flex-1 items-end rounded-3xl bg-tg-input px-3">
            <textarea
              ref={areaRef}
              rows={1}
              value={draft}
              placeholder="Сообщение"
              aria-label="Сообщение"
              className="max-h-36 min-h-10 flex-1 resize-none bg-transparent py-2.5 text-base text-tg-fg placeholder:text-tg-muted"
              onChange={(event) => setDraft(chat.id, event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
                  event.preventDefault();
                  submitText();
                }
              }}
            />
            <button type="button" className="mb-1 grid size-9 place-items-center text-tg-muted" aria-label="Эмодзи" onClick={() => setEmojiOpen((value) => !value)}>
              <Smile className="size-5" />
            </button>
          </div>
          {draft.trim() ? (
            <button type="button" className="grid size-10 place-items-center rounded-full text-tg-primary" aria-label="Отправить" onClick={submitText}>
              <Send className="size-6" />
            </button>
          ) : (
            <button type="button" className="grid size-10 place-items-center rounded-full text-tg-muted" aria-label="Голосовое сообщение" onClick={() => setRecording(Date.now())}>
              <Mic className="size-6" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function ProfileSheet({ chat, onClose }: { chat: Chat; onClose: () => void }) {
  const toggleMute = useChat((s) => s.toggleMute);
  const togglePin = useChat((s) => s.togglePin);
  return (
    <div className="absolute inset-0 z-30 flex justify-end bg-tg-chip">
      <button type="button" className="absolute inset-0" aria-label="Закрыть" onClick={onClose} />
      <aside className="relative flex h-full w-full max-w-md flex-col bg-tg-surface">
        <header className="flex h-header items-center gap-2 px-2">
          <button type="button" className="grid size-10 place-items-center rounded-full hover:bg-tg-hover" aria-label="Закрыть" onClick={onClose}>
            <X className="size-5" />
          </button>
          <h2 className="font-medium">Информация</h2>
        </header>
        <div className="tg-scroll min-h-0 flex-1 overflow-y-auto">
          <div className="flex flex-col items-center px-6 py-6">
            <Avatar chat={chat} className="size-28" />
            <h3 className="mt-3 text-xl font-medium">{chat.title}</h3>
            <p className={cn("mt-1 text-sm", chat.online ? "text-tg-primary" : "text-tg-muted")}>
              {chat.online ? "в сети" : chat.status}
            </p>
          </div>
          <div className="h-2 bg-tg-hover" />
          <button type="button" className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-tg-hover" onClick={() => togglePin(chat.id)}>
            <Pin className="size-5 text-tg-primary" />
            {chat.pinned ? "Открепить" : "Закрепить"}
          </button>
          <button type="button" className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-tg-hover" onClick={() => toggleMute(chat.id)}>
            <BellOff className="size-5 text-tg-primary" />
            {chat.muted ? "Включить уведомления" : "Выключить уведомления"}
          </button>
          {chat.members?.length ? (
            <>
              <div className="h-2 bg-tg-hover" />
              <p className="px-4 py-3 text-sm text-tg-muted">{chat.members.length} участника</p>
              {chat.members.map((member) => (
                <div key={member.name} className="flex items-center gap-3 px-4 py-2">
                  <span className="grid size-10 place-items-center rounded-full text-sm text-tg-on-primary" style={{ background: member.color }}>
                    {member.name[0]}
                  </span>
                  <span>{member.name}</span>
                </div>
              ))}
            </>
          ) : null}
        </div>
      </aside>
    </div>
  );
}
