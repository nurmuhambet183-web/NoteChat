import { useEffect, useState, type ReactNode } from "react";
import { Copy, CornerUpLeft, Trash2 } from "lucide-react";
import { Conversation } from "@/components/notechat/conversation";
import { ContactsPage, MenuDrawer, NewChatPage, NewGroupPage, SettingsPage } from "@/components/notechat/pages";
import { reactionChoices } from "@/components/notechat/bits";
import { Sidebar } from "@/components/notechat/sidebar";
import { cn } from "@/lib/chat/format";
import { useChat } from "@/lib/chat/store";

export function Messenger() {
  const theme = useChat((s) => s.theme);
  const page = useChat((s) => s.page);
  const menuOpen = useChat((s) => s.menuOpen);
  const activeId = useChat((s) => s.activeId);
  const toast = useChat((s) => s.toast);
  const listMenu = useChat((s) => s.listMenu);
  const msgMenu = useChat((s) => s.msgMenu);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      const state = useChat.getState();
      if (state.msgMenu || state.listMenu) {
        state.closeMenus();
        return;
      }
      if (state.menuOpen) {
        state.setMenuOpen(false);
        return;
      }
      if (state.chatSearch) {
        state.setChatSearch(false);
        return;
      }
      if (state.page !== "chats") {
        state.setPage("chats");
        return;
      }
      if (state.activeId && window.innerWidth < 768) state.closeChat();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div data-theme={theme} className="relative flex h-dvh overflow-hidden bg-tg-bg text-tg-fg">
      <aside
        className={cn(
          "relative h-full min-h-0 w-full shrink-0 border-tg-border md:flex md:w-sidebar md:border-r",
          activeId ? "hidden md:flex" : "flex",
        )}
      >
        {page === "chats" ? <Sidebar /> : null}
        {page === "settings" ? <SettingsPage /> : null}
        {page === "contacts" ? <ContactsPage /> : null}
        {page === "new" ? <NewChatPage /> : null}
        {page === "group" ? <NewGroupPage /> : null}
      </aside>
      <section className={cn("relative min-h-0 min-w-0 flex-1 flex-col", activeId ? "flex" : "hidden md:flex")}>
        <Conversation />
      </section>
      {menuOpen ? <MenuDrawer /> : null}
      {toast ? (
        <div className="pointer-events-none absolute bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-tg-chip px-4 py-2 text-sm text-tg-chip-fg">
          {toast}
        </div>
      ) : null}
      {listMenu ? <ListMenu x={listMenu.x} y={listMenu.y} id={listMenu.id} /> : null}
      {msgMenu ? <MessageMenu x={msgMenu.x} y={msgMenu.y} id={msgMenu.id} /> : null}
    </div>
  );
}

function Pop({ x, y, children, onClose }: { x: number; y: number; children: ReactNode; onClose: () => void }) {
  const [pos, setPos] = useState({ left: x, top: y });
  useEffect(() => {
    const width = 240;
    const height = 280;
    setPos({
      left: Math.max(8, Math.min(x, window.innerWidth - width - 8)),
      top: Math.max(8, Math.min(y, window.innerHeight - height - 8)),
    });
  }, [x, y]);
  return (
    <>
      <button type="button" className="fixed inset-0 z-40 cursor-default" aria-label="Закрыть" onClick={onClose} onContextMenu={(event) => { event.preventDefault(); onClose(); }} />
      <div className="tg-pop fixed z-50 w-60 overflow-hidden rounded-xl bg-tg-surface py-1 text-sm" style={{ left: pos.left, top: pos.top }}>
        {children}
      </div>
    </>
  );
}

function Item({ label, onClick, danger }: { label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button type="button" className={cn("block w-full px-4 py-2.5 text-left hover:bg-tg-hover", danger && "text-tg-danger")} onClick={onClick}>
      {label}
    </button>
  );
}

function ListMenu({ x, y, id }: { x: number; y: number; id: string }) {
  const chat = useChat((s) => s.chats.find((item) => item.id === id));
  const closeMenus = useChat((s) => s.closeMenus);
  const togglePin = useChat((s) => s.togglePin);
  const toggleMute = useChat((s) => s.toggleMute);
  const toggleArchive = useChat((s) => s.toggleArchive);
  const markUnread = useChat((s) => s.markUnread);
  if (!chat) return null;
  return (
    <Pop x={x} y={y} onClose={closeMenus}>
      <Item label={chat.pinned ? "Открепить" : "Закрепить"} onClick={() => togglePin(id)} />
      <Item label={chat.muted ? "Включить звук" : "Выключить звук"} onClick={() => toggleMute(id)} />
      <Item label={chat.archived ? "Вернуть из архива" : "В архив"} onClick={() => toggleArchive(id)} />
      <Item label="Пометить непрочитанным" onClick={() => markUnread(id)} />
    </Pop>
  );
}

function MessageMenu({ x, y, id }: { x: number; y: number; id: string }) {
  const message = useChat((s) => s.messages.find((item) => item.id === id));
  const closeMenus = useChat((s) => s.closeMenus);
  const setReply = useChat((s) => s.setReply);
  const deleteMessage = useChat((s) => s.deleteMessage);
  const toggleReaction = useChat((s) => s.toggleReaction);
  const showToast = useChat((s) => s.showToast);
  if (!message || message.service) return null;
  return (
    <Pop x={x} y={y} onClose={closeMenus}>
      <div className="flex justify-between px-3 py-2">
        {reactionChoices().map((emoji) => (
          <button key={emoji} type="button" className="grid size-8 place-items-center rounded-full text-lg hover:bg-tg-hover" onClick={() => toggleReaction(id, emoji)}>
            {emoji}
          </button>
        ))}
      </div>
      <button type="button" className="flex w-full items-center gap-3 px-4 py-2.5 text-left hover:bg-tg-hover" onClick={() => setReply(id)}>
        <CornerUpLeft className="size-4 text-tg-muted" /> Ответить
      </button>
      <button
        type="button"
        className="flex w-full items-center gap-3 px-4 py-2.5 text-left hover:bg-tg-hover"
        onClick={() => {
          const text = message.text || message.file?.name || "";
          void navigator.clipboard.writeText(text).then(
            () => showToast("Скопировано"),
            () => showToast("Не удалось скопировать"),
          );
          closeMenus();
        }}
      >
        <Copy className="size-4 text-tg-muted" /> Копировать
      </button>
      <button type="button" className="flex w-full items-center gap-3 px-4 py-2.5 text-left text-tg-danger hover:bg-tg-hover" onClick={() => deleteMessage(id)}>
        <Trash2 className="size-4" /> Удалить
      </button>
    </Pop>
  );
}
