import { useState } from "react";
import { ArrowLeft, Bookmark, Moon, Phone, Settings, UserPlus, UserRound, Users } from "lucide-react";
import { useChat } from "@/lib/chat/store";
import { cn, initials } from "@/lib/chat/format";
import { LetterAvatar } from "@/components/notechat/bits";

export function MenuDrawer() {
  const profile = useChat((s) => s.profile);
  const theme = useChat((s) => s.theme);
  const setMenuOpen = useChat((s) => s.setMenuOpen);
  const setPage = useChat((s) => s.setPage);
  const toggleTheme = useChat((s) => s.toggleTheme);
  const openChat = useChat((s) => s.openChat);
  const showToast = useChat((s) => s.showToast);

  return (
    <div className="absolute inset-0 z-30">
      <button type="button" className="absolute inset-0 bg-tg-chip" aria-label="Закрыть меню" onClick={() => setMenuOpen(false)} />
      <nav className="tg-drawer absolute inset-y-0 left-0 flex w-menu flex-col bg-tg-menu text-tg-fg">
        <button
          type="button"
          className="flex items-center gap-3 px-4 py-5 text-left hover:bg-tg-hover"
          onClick={() => setPage("settings")}
        >
          <LetterAvatar name={profile.name} color={profile.color} className="size-14 bg-tg-primary text-xl" />
          <span className="min-w-0">
            <span className="block truncate text-lg font-medium">{profile.name}</span>
            <span className="block truncate text-sm text-tg-muted">{profile.phone}</span>
          </span>
        </button>
        <div className="h-2 bg-tg-hover" />
        <MenuRow icon={UserPlus} label="Новая группа" onClick={() => setPage("group")} />
        <MenuRow icon={UserRound} label="Контакты" onClick={() => setPage("contacts")} />
        <MenuRow icon={Phone} label="Звонки" onClick={() => showToast("Звонки появятся в следующем обновлении")} />
        <MenuRow icon={Bookmark} label="Избранное" onClick={() => openChat("saved")} />
        <MenuRow icon={Settings} label="Настройки" onClick={() => setPage("settings")} />
        <div className="h-2 bg-tg-hover" />
        <button type="button" className="flex items-center gap-4 px-4 py-3 text-left hover:bg-tg-hover" onClick={toggleTheme}>
          <Moon className="size-6 text-tg-primary" />
          <span className="flex-1">Ночной режим</span>
          <span className={cn("flex h-6 w-11 rounded-full p-0.5", theme === "night" ? "bg-tg-primary" : "bg-tg-badge-muted")}>
            <span className={cn("block size-5 rounded-full bg-tg-on-primary transition-transform", theme === "night" && "translate-x-5")} />
          </span>
        </button>
        <p className="mt-auto px-4 py-4 text-meta text-tg-muted">NoteChat Web</p>
      </nav>
    </div>
  );
}

function MenuRow({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof Settings;
  label: string;
  onClick: () => void;
}) {
  return (
    <button type="button" className="flex w-full items-center gap-4 px-4 py-3 text-left hover:bg-tg-hover" onClick={onClick}>
      <Icon className="size-6 text-tg-primary" />
      <span>{label}</span>
    </button>
  );
}

function SubHeader({ title }: { title: string }) {
  const setPage = useChat((s) => s.setPage);
  return (
    <header className="flex h-header shrink-0 items-center gap-1 px-1">
      <button type="button" className="grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover" aria-label="Назад" onClick={() => setPage("chats")}>
        <ArrowLeft className="size-6" />
      </button>
      <h1 className="text-lg font-medium">{title}</h1>
    </header>
  );
}

export function SettingsPage() {
  const profile = useChat((s) => s.profile);
  const theme = useChat((s) => s.theme);
  const setProfile = useChat((s) => s.setProfile);
  const toggleTheme = useChat((s) => s.toggleTheme);

  return (
    <div className="flex h-full min-h-0 flex-col bg-tg-bg">
      <SubHeader title="Настройки" />
      <div className="tg-scroll min-h-0 flex-1 overflow-y-auto">
        <div className="flex flex-col items-center px-8 py-6">
          <LetterAvatar name={profile.name || "•"} color={profile.color} className="size-24 bg-tg-primary text-3xl" />
          <input
            value={profile.name}
            onChange={(event) => setProfile({ name: event.target.value })}
            aria-label="Имя"
            className="mt-4 w-full border-b border-tg-border bg-transparent py-1 text-center text-lg text-tg-fg"
          />
          <input
            value={profile.bio}
            onChange={(event) => setProfile({ bio: event.target.value })}
            aria-label="О себе"
            placeholder="О себе"
            className="mt-2 w-full bg-transparent py-1 text-center text-sm text-tg-muted placeholder:text-tg-muted"
          />
          <p className="mt-2 text-meta text-tg-muted">{profile.phone}</p>
        </div>
        <div className="h-2 bg-tg-hover" />
        <button type="button" className="flex w-full items-center gap-4 px-4 py-3.5 text-left hover:bg-tg-hover" onClick={toggleTheme}>
          <Moon className="size-6 text-tg-primary" />
          <span className="flex-1">Ночной режим</span>
          <span className={cn("flex h-6 w-11 rounded-full p-0.5", theme === "night" ? "bg-tg-primary" : "bg-tg-badge-muted")}>
            <span className={cn("block size-5 rounded-full bg-tg-on-primary transition-transform", theme === "night" && "translate-x-5")} />
          </span>
        </button>
        <p className="px-4 py-4 text-sm leading-relaxed text-tg-muted">
          NoteChat хранит переписку на этом устройстве. Напишите человеку из списка — он ответит прямо в чате.
        </p>
        <p className="px-4 pb-6 text-meta text-tg-muted">Инициалы: {initials(profile.name)}</p>
      </div>
    </div>
  );
}

export function ContactsPage() {
  const chats = useChat((s) => s.chats);
  const openChat = useChat((s) => s.openChat);
  const people = chats
    .filter((chat) => chat.kind === "user" && !chat.archived)
    .slice()
    .sort((a, b) => a.title.localeCompare(b.title, "ru"));

  return (
    <div className="flex h-full min-h-0 flex-col bg-tg-bg">
      <SubHeader title="Контакты" />
      <div className="tg-scroll min-h-0 flex-1 overflow-y-auto">
        {people.map((chat) => (
          <button
            key={chat.id}
            type="button"
            className="flex h-row w-full items-center gap-3 px-3 text-left hover:bg-tg-hover"
            onClick={() => openChat(chat.id)}
          >
            <LetterAvatar name={chat.title} color={chat.color} className="size-12 text-base" />
            <span className="min-w-0">
              <span className="block truncate font-medium">{chat.title}</span>
              <span className="block truncate text-sm text-tg-muted">{chat.online ? "в сети" : chat.status}</span>
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function NewChatPage() {
  const [name, setName] = useState("");
  const chats = useChat((s) => s.chats);
  const createContact = useChat((s) => s.createContact);
  const openChat = useChat((s) => s.openChat);
  const people = chats.filter((chat) => chat.kind === "user" && !chat.archived);

  return (
    <div className="flex h-full min-h-0 flex-col bg-tg-bg">
      <SubHeader title="Новое сообщение" />
      <form
        className="flex gap-2 px-3 py-2"
        onSubmit={(event) => {
          event.preventDefault();
          createContact(name);
          setName("");
        }}
      >
        <input
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Имя нового контакта"
          aria-label="Имя нового контакта"
          className="h-11 min-w-0 flex-1 rounded-full bg-tg-input px-4 text-base text-tg-fg placeholder:text-tg-muted"
        />
        <button type="submit" className="h-11 rounded-full bg-tg-primary px-4 text-sm font-medium text-tg-on-primary" disabled={!name.trim()}>
          Создать
        </button>
      </form>
      <div className="tg-scroll min-h-0 flex-1 overflow-y-auto">
        {people.map((chat) => (
          <button
            key={chat.id}
            type="button"
            className="flex h-14 w-full items-center gap-3 px-3 text-left hover:bg-tg-hover"
            onClick={() => openChat(chat.id)}
          >
            <LetterAvatar name={chat.title} color={chat.color} className="size-11 text-sm" />
            <span className="truncate font-medium">{chat.title}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function NewGroupPage() {
  const [name, setName] = useState("");
  const createGroup = useChat((s) => s.createGroup);

  return (
    <div className="flex h-full min-h-0 flex-col bg-tg-bg">
      <SubHeader title="Новая группа" />
      <form
        className="flex flex-col gap-3 px-4 py-4"
        onSubmit={(event) => {
          event.preventDefault();
          createGroup(name);
        }}
      >
        <div className="grid size-20 place-items-center self-center rounded-full bg-tg-input text-tg-muted">
          <Users className="size-8" />
        </div>
        <input
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Название группы"
          aria-label="Название группы"
          className="h-11 rounded-full bg-tg-input px-4 text-base text-tg-fg placeholder:text-tg-muted"
        />
        <button type="submit" className="h-11 rounded-full bg-tg-primary text-sm font-medium text-tg-on-primary" disabled={!name.trim()}>
          Создать группу
        </button>
      </form>
    </div>
  );
}
