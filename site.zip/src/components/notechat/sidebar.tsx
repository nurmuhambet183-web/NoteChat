import { Archive, BellOff, Menu, Pencil, Pin, Search } from "lucide-react";
import type { Chat, FolderId, Msg } from "@/lib/chat/types";
import { cn, formatListTime } from "@/lib/chat/format";
import { useChat } from "@/lib/chat/store";
import { Avatar } from "@/components/notechat/bits";

const FOLDERS: { id: FolderId; label: string }[] = [
  { id: "all", label: "Все" },
  { id: "personal", label: "Личные" },
  { id: "work", label: "Работа" },
  { id: "groups", label: "Группы" },
];

function inFolder(chat: Chat, folder: FolderId) {
  if (folder === "archive") return Boolean(chat.archived);
  if (chat.archived) return false;
  if (folder === "all") return true;
  if (folder === "personal") return chat.kind === "user" || chat.kind === "saved" || chat.kind === "channel";
  if (folder === "groups") return chat.kind === "group";
  return chat.folder === "work";
}

function lastMessage(messages: Msg[], chatId: string) {
  for (let index = messages.length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    if (message && message.chatId === chatId && !message.service) return message;
  }
  return undefined;
}

function previewText(message: Msg | undefined) {
  if (!message) return "";
  if (message.voice) return "Голосовое сообщение";
  if (message.file) return message.file.name;
  return message.text;
}

export function Sidebar() {
  const folder = useChat((s) => s.folder);
  const query = useChat((s) => s.query);
  const chats = useChat((s) => s.chats);
  const messages = useChat((s) => s.messages);
  const activeId = useChat((s) => s.activeId);
  const typingChatId = useChat((s) => s.typingChatId);
  const setFolder = useChat((s) => s.setFolder);
  const setQuery = useChat((s) => s.setQuery);
  const setMenuOpen = useChat((s) => s.setMenuOpen);
  const openChat = useChat((s) => s.openChat);
  const setPage = useChat((s) => s.setPage);
  const setListMenu = useChat((s) => s.setListMenu);
  const closeMenus = useChat((s) => s.closeMenus);

  const archivedCount = chats.filter((chat) => chat.archived).length;
  const needle = query.trim().toLowerCase();

  const visible = chats
    .filter((chat) => {
      if (needle) {
        const last = lastMessage(messages, chat.id);
        const blob = `${chat.title} ${previewText(last)}`.toLowerCase();
        return blob.includes(needle);
      }
      return inFolder(chat, folder);
    })
    .sort((a, b) => {
      const left = lastMessage(messages, a.id)?.at ?? 0;
      const right = lastMessage(messages, b.id)?.at ?? 0;
      if (!needle && folder !== "archive" && Boolean(a.pinned) !== Boolean(b.pinned)) return a.pinned ? -1 : 1;
      return right - left;
    });

  return (
    <div className="flex h-full min-h-0 flex-col bg-tg-bg">
      <header className="flex h-header shrink-0 items-center gap-2 px-2">
        <button
          type="button"
          className="grid size-10 place-items-center rounded-full text-tg-muted hover:bg-tg-hover"
          aria-label="Меню"
          onClick={() => setMenuOpen(true)}
        >
          <Menu className="size-6" />
        </button>
        <label className="flex h-10 min-w-0 flex-1 items-center gap-2 rounded-full bg-tg-input px-3 text-tg-muted">
          <Search className="size-4 shrink-0" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Поиск"
            className="min-w-0 flex-1 bg-transparent text-base text-tg-fg placeholder:text-tg-muted"
            aria-label="Поиск"
          />
        </label>
      </header>

      {folder === "archive" ? (
        <div className="flex h-12 shrink-0 items-center gap-2 border-b border-tg-border px-2">
          <button type="button" className="px-2 text-tg-primary" onClick={() => setFolder("all")}>
            Назад
          </button>
          <h2 className="font-medium">Архив</h2>
        </div>
      ) : (
        <div className="no-scrollbar flex shrink-0 gap-4 overflow-x-auto border-b border-tg-border px-4">
          {FOLDERS.map((item) => {
            const active = folder === item.id;
            return (
              <button
                key={item.id}
                type="button"
                className={cn("relative py-3 text-sm font-medium", active ? "text-tg-primary" : "text-tg-muted")}
                onClick={() => setFolder(item.id)}
              >
                {item.label}
                {active ? <span className="absolute inset-x-0 -bottom-px h-0.5 rounded-full bg-tg-primary" /> : null}
              </button>
            );
          })}
        </div>
      )}

      <div className="tg-scroll min-h-0 flex-1 overflow-y-auto pb-24" onScroll={closeMenus}>
        {folder === "all" && !needle && archivedCount > 0 ? (
          <button
            type="button"
            className="flex h-row w-full items-center gap-3 px-3 text-left hover:bg-tg-hover"
            onClick={() => setFolder("archive")}
          >
            <span className="grid size-avatar place-items-center rounded-full bg-tg-input text-tg-muted">
              <Archive className="size-6" />
            </span>
            <span className="font-medium">Архив</span>
            <span className="ml-auto text-sm text-tg-primary">{archivedCount}</span>
          </button>
        ) : null}

        {visible.length === 0 ? (
          <p className="px-6 py-10 text-center text-sm text-tg-muted">Ничего не найдено</p>
        ) : null}

        {visible.map((chat) => {
          const active = chat.id === activeId;
          const last = lastMessage(messages, chat.id);
          const typing = typingChatId === chat.id;
          const draft = chat.draft?.trim();
          const time = last ? formatListTime(last.at) : "";
          let body = previewText(last);
          if (last?.out && body) body = `Вы: ${body}`;
          return (
            <button
              key={chat.id}
              type="button"
              className={cn(
                "flex h-row w-full items-center gap-3 overflow-hidden px-2.5 text-left",
                active ? "bg-tg-active text-tg-on-active" : "hover:bg-tg-hover",
              )}
              onClick={() => openChat(chat.id)}
              onContextMenu={(event) => {
                event.preventDefault();
                setListMenu({ id: chat.id, x: event.clientX, y: event.clientY });
              }}
            >
              <Avatar chat={chat} active={active} className="size-avatar" />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className={cn("min-w-0 flex-1 truncate", chat.unread ? "font-semibold" : "font-medium")}>{chat.title}</span>
                  <span
                    className={cn(
                      "flex shrink-0 items-center gap-1 text-meta tabular-nums",
                      active ? "text-tg-on-active-dim" : chat.unread ? "text-tg-primary" : "text-tg-muted",
                    )}
                  >
                    {chat.pinned ? <Pin className="size-3.5" /> : null}
                    {chat.muted ? <BellOff className="size-3.5" /> : null}
                    {time}
                  </span>
                </span>
                <span className="mt-0.5 flex items-center gap-2">
                  <span
                    className={cn(
                      "min-w-0 flex-1 truncate text-sm",
                      active ? "text-tg-on-active-dim" : typing || draft ? "text-tg-primary" : "text-tg-muted",
                    )}
                  >
                    {typing ? "печатает…" : draft ? `Черновик: ${draft}` : body || "Нет сообщений"}
                  </span>
                  {chat.unread > 0 ? (
                    <span
                      className={cn(
                        "grid h-5 min-w-5 shrink-0 place-items-center rounded-full px-1.5 text-meta font-medium",
                        active
                          ? "bg-tg-on-primary text-tg-primary"
                          : chat.muted
                            ? "bg-tg-badge-muted text-tg-on-primary"
                            : "bg-tg-primary text-tg-on-primary",
                      )}
                    >
                      {chat.unread > 99 ? "99+" : chat.unread}
                    </span>
                  ) : null}
                </span>
              </span>
            </button>
          );
        })}
      </div>

      <button
        type="button"
        className="tg-fab absolute bottom-5 right-5 grid size-14 place-items-center rounded-full bg-tg-primary text-tg-on-primary"
        aria-label="Новое сообщение"
        onClick={() => setPage("new")}
      >
        <Pencil className="size-6" />
      </button>
    </div>
  );
}
