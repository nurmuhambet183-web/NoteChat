import { Bookmark, Feather } from "lucide-react";
import type { Chat } from "@/lib/chat/types";
import { cn, initials } from "@/lib/chat/format";

export function LetterAvatar({
  name,
  color,
  className,
  saved,
  channel,
}: {
  name: string;
  color: string;
  className?: string;
  saved?: boolean;
  channel?: boolean;
}) {
  return (
    <span
      className={cn("grid shrink-0 place-items-center rounded-full font-medium text-tg-on-primary", className)}
      style={{ background: saved || channel ? undefined : color }}
    >
      {saved ? (
        <Bookmark className="size-[46%]" fill="currentColor" />
      ) : channel ? (
        <Feather className="size-[52%]" strokeWidth={1.75} />
      ) : (
        initials(name)
      )}
    </span>
  );
}

export function Avatar({
  chat,
  className,
  active,
}: {
  chat: Chat;
  className?: string;
  active?: boolean;
}) {
  return (
    <span className={cn("relative shrink-0", className)}>
      <LetterAvatar
        name={chat.title}
        color={chat.color}
        saved={chat.kind === "saved"}
        channel={chat.kind === "channel"}
        className={cn(
          "size-full text-lg",
          (chat.kind === "saved" || chat.kind === "channel") && "bg-tg-primary",
        )}
      />
      {chat.online ? (
        <span
          className={cn(
            "absolute bottom-0 right-0 size-3.5 rounded-full border-2 bg-tg-online",
            active ? "border-tg-active" : "border-tg-bg",
          )}
        />
      ) : null}
    </span>
  );
}

export function BubbleTail({ out }: { out: boolean }) {
  return (
    <svg
      viewBox="0 0 11 20"
      className={cn(
        "absolute bottom-0 h-5 w-3",
        out ? "-right-1.5 text-tg-bubble-out" : "-left-1.5 -scale-x-100 text-tg-bubble-in",
      )}
      aria-hidden="true"
    >
      <path fill="currentColor" d="M0 0c.6 3.2 2.2 6.6 5.2 10.2C7.4 13 9.2 15.2 11 17.2V20H6.2C3.4 16.4 1.2 11.2 0 0Z" />
    </svg>
  );
}

const REACTIONS = ["👍", "❤️", "🔥", "🎉", "😁", "👎"];

export function reactionChoices() {
  return REACTIONS;
}
